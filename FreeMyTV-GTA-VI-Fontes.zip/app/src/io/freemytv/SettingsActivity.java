package io.freemytv;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.Choreographer;
import android.view.KeyEvent;
import android.view.View;
import android.view.accessibility.AccessibilityNodeProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/**
 * TV settings with a persisted appearance selector and skin-owned materials/fonts. "Home screen"
 * opens the Free My TV / Original choice (with a check on the current one); the switch runs in the main process
 * (HomeMode) and this screen only asks for it and follows the state file.
 */
public class SettingsActivity extends Activity {
    private SettingsView view;
    private DreamView preview;   // "Screensaver": the screensaver right here, without changing the system setting

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Watchdog.install(this);
        Ui.init(this);
        view = new SettingsView(this);
        setContentView(view);
    }

    @Override protected void onResume() {
        super.onResume();
        view.resume();
        // From ADB: am start -n io.freemytv/.SettingsActivity --ez screensaver true (straight to the preview).
        if (preview == null && getIntent().getBooleanExtra("screensaver", false)) {
            getIntent().removeExtra("screensaver");
            view.pause();
            showPreview();
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override protected void onPause() {
        closePreview();     // before pausing the view: closing the preview resumes it (view.resume)
        view.pause();
        super.onPause();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (preview != null) {
            // Like the real screensaver: arrows, OK or Back close it (other keys go on to the system).
            switch (event.getKeyCode()) {
                case KeyEvent.KEYCODE_DPAD_UP:
                case KeyEvent.KEYCODE_DPAD_DOWN:
                case KeyEvent.KEYCODE_DPAD_LEFT:
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_BACK:
                    if (event.getAction() == KeyEvent.ACTION_UP) closePreview();
                    return true;
                default:
                    return super.dispatchKeyEvent(event);
            }
        }
        if (view.onKey(event)) return true;
        return super.dispatchKeyEvent(event);
    }

    void showPreview() {
        preview = new DreamView(this);
        setContentView(preview);
        preview.start();
    }

    private void closePreview() {
        if (preview == null) return;
        preview.stop();
        preview = null;
        setContentView(view);
        view.resume();
    }

    static final class SettingsView extends View implements Choreographer.FrameCallback {
        private static final int MAIN = 0, HOME_CHOICE = 1, SKIN_CHOICE = 2;
        private static final float LIST_X = 1000, LIST_R = 1824, LIST_TOP = 186, ROW_H = 74, ROW_GAP = 8, CHOICE_H = 104;
        private static final int AMBER = 0xFFFFC266;
        private Skin skin;
        private Ui.Fonts fonts;
        private final Skin.Palette theme = new Skin.Palette();
        private final Scene scene = new Scene();
        private final HomeData data;
        private boolean night;

        private final SettingsActivity activity;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Spring[] pop = new Spring[5];
        private final RectF tmp = new RectF(), rowRect = new RectF(), focusBox = new RectF();
        private JSONObject state = new JSONObject(), recs = new JSONObject();
        private boolean channelConfigured;
        private String channelLine = "", channelTimestamp = "", subscriptionsLine = "", subscriptionsTimestamp = "";
        private int screen = MAIN, focus;
        private boolean running, okDown, backDown, wasBusy;
        private final Spoken spoken;
        private long startedAt, lastNanos, pendingAt, lastSky;
        private int w, h;
        private float k = 1;
        private Paint title, subtitle, version, rowLabel, rowValue, rowSub, header, cellLabel, cellValue, warn, spinner, white, shadow;
        private TextPaint notice;

        private final Runnable poll = new Runnable() {
            @Override public void run() {
                if (!running) return;
                state = HomeMode.state(getContext());
                channelConfigured = Recs.hasKey(getContext());
                recs = Recs.status(getContext());
                updateChannelStatus();
                refreshAppearance();
                boolean nowBusy = !state.optString("busy").isEmpty();
                if (nowBusy) pendingAt = 0;
                // A switch just ended: TalkBack reads how it went (the newest notice).
                JSONArray notices = state.optJSONArray("notices");
                if (wasBusy && !nowBusy && notices != null && notices.length() > 0) {
                    JSONObject newest = notices.optJSONObject(0);
                    if (newest != null) announceForAccessibility(newest.optString("text"));
                }
                wasBusy = nowBusy;
                invalidate();
                handler.postDelayed(this, 500);
            }
        };

        SettingsView(SettingsActivity a) {
            super(a);
            activity = a;
            data = HomeData.get(a);
            refreshAppearance();
            for (int i = 0; i < pop.length; i++) pop[i] = new Spring(0.28f, 0.85f, 0);
            setFocusable(true);
            setContentDescription("Free My TV");
            // TalkBack: one item per row, id = row + 1.
            spoken = new Spoken(this, new Spoken.Source() {
                @Override public void items(List<Integer> out) { for (int i = 1; i <= rowCount(); i++) out.add(i); }
                @Override public String text(int id) { return id >= 1 && id <= rowCount() ? rowText(id - 1) : ""; }
                @Override public boolean bounds(int id, Rect out) {
                    if (id < 1 || id > rowCount()) return false;
                    rowBox(id - 1).round(out);
                    return true;
                }
                @Override public int focused() { return focus + 1; }
                @Override public void focus(int id) {
                    focus = id - 1;
                    invalidate();
                }
                @Override public void click(int id) { activate(); }
            });
        }

        @Override public AccessibilityNodeProvider getAccessibilityNodeProvider() {
            return spoken;
        }

        /** A row as TalkBack reads it: its name and its value. */
        private String rowText(int row) {
            if (screen == MAIN) {
                if (row == 0) {
                    String busyText = state.optString("busy");
                    String value = busy() ? (busyText.isEmpty() ? Ui.tr("Começando…", "Starting…") : busyText)
                            : freeActive() ? "Free My TV" : Ui.tr("Original", "Original");
                    return Ui.tr("Início, ", "Home Screen, ") + value;
                }
                if (row == 1) return Ui.tr("Aparência, ", "Appearance, ") + skinName(skin);
                return row == 2 ? Ui.tr("Tela de Descanso, ver agora", "Screensaver, preview") : Ui.tr("Ajustes da TV", "TV Settings");
            }
            if (screen == SKIN_CHOICE) {
                Skin option = Skin.values()[row];
                return skinName(option) + (option == skin ? Ui.tr(". Em uso", ". In use") : "");
            }
            String name = row == 0 ? "Free My TV, " + Ui.tr("sem anúncios, com a tela de descanso nova", "no ads, with the new screensaver")
                    : "Original, " + Ui.tr("o Início de fábrica da TV", "the TV's factory home screen");
            boolean inUse = (row == 0) == freeActive();
            return name + (inUse ? Ui.tr(". Em uso", ". In use") : "") + ", " + (row + 1) + Ui.tr(" de 2", " of 2");
        }

        private RectF rowBox(int row) {
            float top = screen == MAIN ? LIST_TOP + row * (ROW_H + ROW_GAP) : LIST_TOP + 20 + row * (CHOICE_H + ROW_GAP);
            float height = screen == MAIN ? ROW_H : CHOICE_H;
            focusBox.set(LIST_X * k, top * k, LIST_R * k, (top + height) * k);
            return focusBox;
        }

        void resume() {
            refreshAppearance();
            if (running) return;
            running = true;
            startedAt = SystemClock.uptimeMillis();
            lastNanos = 0;
            handler.post(poll);
            Choreographer.getInstance().postFrameCallback(this);
            spoken.readAgain();
        }

        void pause() {
            running = false;
            handler.removeCallbacks(poll);
            Choreographer.getInstance().removeFrameCallback(this);
        }

        @Override public void doFrame(long frameTimeNanos) {
            if (!running) return;
            boolean moving = busy();
            for (Spring s : pop) moving |= !s.settled();
            if (moving || SystemClock.uptimeMillis() - lastSky >= 100) invalidate();
            Choreographer.getInstance().postFrameCallback(this);
        }

        @Override protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
            w = width;
            h = height;
            k = w / 1920f;
            scene.setSize(w, h);
            title = Ui.text(fonts.displaySemibold, 50 * k, theme.TEXT);
            title.setTextAlign(Paint.Align.CENTER);
            subtitle = Ui.text(fonts.regular, 26 * k, theme.SECONDARY);
            subtitle.setTextAlign(Paint.Align.CENTER);
            version = Ui.text(fonts.mono, 20 * k, theme.MUTED);
            version.setTextAlign(Paint.Align.CENTER);
            rowLabel = Ui.text(fonts.medium, 30 * k, theme.TEXT);
            rowValue = Ui.text(fonts.regular, 28 * k, theme.SECONDARY);
            rowValue.setTextAlign(Paint.Align.RIGHT);
            rowSub = Ui.text(fonts.regular, 23 * k, theme.SECONDARY);
            header = Ui.text(fonts.mono, 20 * k, theme.ACCENT);
            header.setLetterSpacing(0.06f);
            cellLabel = Ui.text(fonts.regular, 25 * k, theme.SECONDARY);
            cellValue = fonts.numbers(fonts.regular, 25 * k, theme.SECONDARY);
            cellValue.setTextAlign(Paint.Align.RIGHT);
            warn = Ui.text(fonts.regular, 23 * k, AMBER);
            notice = new TextPaint(Ui.text(fonts.regular, 23 * k, theme.MUTED));
            spinner = new Paint(Paint.ANTI_ALIAS_FLAG);
            spinner.setStyle(Paint.Style.STROKE);
            spinner.setStrokeCap(Paint.Cap.ROUND);
            spinner.setStrokeWidth(3.5f * k);
            white = new Paint(Paint.ANTI_ALIAS_FLAG);
            white.setColor(theme.FOCUS);
            shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
            shadow.setMaskFilter(new BlurMaskFilter(22 * k, BlurMaskFilter.Blur.NORMAL));
        }

        private boolean busy() {
            return !state.optString("busy").isEmpty() || (pendingAt != 0 && SystemClock.uptimeMillis() - pendingAt < 10_000);
        }

        private boolean freeActive() {
            return HomeMode.FREE.equals(state.optString("mode")) && !state.optBoolean("homeReverted");
        }

        private int rowCount() {
            return screen == MAIN ? 4 : screen == SKIN_CHOICE ? Skin.values().length : 2;
        }

        @Override protected void onDraw(Canvas c) {
            if (w == 0) return;
            long now = System.nanoTime();
            float dt = lastNanos == 0 ? 1 / 60f : Math.min(0.05f, (now - lastNanos) / 1e9f);
            lastNanos = now;
            for (int i = 0; i < pop.length; i++) {
                pop[i].target = i == focus && i < rowCount() ? 1 : 0;
                pop[i].step(dt);
            }
            long up = SystemClock.uptimeMillis();
            float seconds = (up - startedAt) / 1000f;
            lastSky = up;
            c.drawColor(theme.BACKGROUND);
            if (skin.glass) {
                scene.advance(seconds);
                scene.drawBackground(c);
                white.setColor(Ui.alpha(theme.BACKGROUND, .65f));
                c.drawRect(0, 0, w, h, white);
            }
            white.setColor(theme.FOCUS);

            // On the left: big symbol, title, description.
            float cx = 500 * k;
            if (!skin.glass) Ui.brand(c, cx - 65 * k, 330 * k, 130 * k);
            else Symbols.draw(getContext(), c, "tv", cx, 400 * k, 130 * k, theme.TEXT);
            c.drawText("ViktorKav", cx, 612 * k, title);
            c.drawText(Ui.tr("Início e tela de descanso da TV", "Your TV's home screen and screensaver"), cx, 660 * k, subtitle);
            c.drawText(versionName(getContext()), cx, 704 * k, version);

            if (screen == MAIN) drawMain(c, seconds); else if (screen == SKIN_CHOICE) drawSkins(c); else drawChoice(c);
        }

        private void drawMain(Canvas c, float seconds) {
            boolean working = busy();
            String busyText = state.optString("busy");
            String mode = freeActive() ? "Free My TV" : Ui.tr("Original", "Original");
            String[] labels = {Ui.tr("Início", "Home Screen"), Ui.tr("Aparência", "Appearance"), Ui.tr("Tela de Descanso", "Screensaver"), Ui.tr("Ajustes da TV", "TV Settings")};
            String[] values = {working ? "" : mode, skinName(skin), Ui.tr("Ver agora", "Preview"), ""};
            for (int i = 0; i < 4; i++) {
                float y = (LIST_TOP + i * (ROW_H + ROW_GAP)) * k;
                rowRect.set(LIST_X * k, y, LIST_R * k, y + ROW_H * k);
                float f = drawRowBackground(c, i);
                int ink = blend(theme.TEXT, theme.ON_FOCUS, f);
                rowLabel.setColor(ink);
                float base = rowRect.centerY() + Ui.halfCap(rowLabel);
                c.drawText(labels[i], rowRect.left + 30 * k, base, rowLabel);
                float right = rowRect.right - 30 * k;
                if (i == 3) {
                    float cw = Symbols.width(getContext(), "chevron_right", 22 * k);
                    Symbols.draw(getContext(), c, "chevron_right", right - cw / 2, rowRect.centerY(), 22 * k, blend(theme.MUTED, theme.ON_FOCUS, f));
                } else if (i == 0 && working) {
                    // Switching: the current step in place of the value, with the spinning arc.
                    String text = busyText.isEmpty() ? Ui.tr("Começando…", "Starting…") : busyText;
                    rowValue.setColor(blend(theme.MUTED, theme.ON_FOCUS, f));
                    String shown = TextUtils.ellipsize(text, new TextPaint(rowValue), 470 * k, TextUtils.TruncateAt.END).toString();
                    c.drawText(shown, right, base, rowValue);
                    float sx = right - rowValue.measureText(shown) - 26 * k;
                    spinner.setColor(blend(theme.TEXT, theme.ON_FOCUS, f));
                    Ui.spinner(c, sx, rowRect.centerY(), 12 * k, seconds * 1.3f, spinner);
                } else {
                    rowValue.setColor(blend(theme.SECONDARY, theme.ON_FOCUS, f));
                    c.drawText(values[i], right, base, rowValue);
                }
            }

            float y = (LIST_TOP + 4 * (ROW_H + ROW_GAP) + 46) * k;
            String error = state.optString("error");
            if (working && (busyText.contains("Permitir") || busyText.contains("Allow"))) {
                c.drawText(Ui.tr("Na TV: marque “Sempre permitir” e aperte OK.", "On the TV: tick “Always allow” and press OK."),
                        LIST_X * k + 30 * k, y, warn);
                y += 46 * k;
            } else if (!working && !error.isEmpty()) {
                c.drawText(TextUtils.ellipsize(error, new TextPaint(warn), 760 * k, TextUtils.TruncateAt.END).toString(), LIST_X * k + 30 * k, y, warn);
                y += 46 * k;
            }
            y = drawComparison(c, y);
            y = drawRecs(c, y + 26 * k);
            drawNotices(c, y + 40 * k);
        }

        private void updateChannelStatus() {
            String error = recs.optString("error");
            long at = recs.optLong("at");
            if (!channelConfigured) channelLine = Ui.tr("Métricas: fonte não configurada.", "Metrics: feed is not configured.");
            else if (!error.isEmpty()) channelLine = Ui.tr("Métricas: ", "Metrics: ") + error + ".";
            else if (at > 0) channelLine = Ui.tr("Métricas públicas do canal ViktorKav.", "Public metrics for the ViktorKav channel.");
            else channelLine = Ui.tr("Métricas: aguardando o feed…", "Metrics: waiting for the feed…");
            boolean stale = recs.optBoolean("stale", true) || at <= 0 || System.currentTimeMillis() < at
                    || System.currentTimeMillis() - at >= 15 * 60_000L;
            channelTimestamp = dataTimestamp(at, stale);

            String status = recs.optString("recommendationsStatus", "loading");
            int count = recs.optInt("recommendationsCount");
            if (!channelConfigured) subscriptionsLine = Ui.tr("Inscrições: fonte não configurada.", "Subscriptions: feed is not configured.");
            else if (status.equals("authorization_required")) subscriptionsLine = Ui.tr("Inscrições: autorize o YouTube no servidor.", "Subscriptions: authorize YouTube on the server.");
            else if (status.equals("loading")) subscriptionsLine = Ui.tr("Inscrições: carregando vídeos…", "Subscriptions: loading videos…");
            else if (status.equals("unavailable")) subscriptionsLine = count > 0
                    ? Ui.tr("Inscrições: últimos vídeos salvos · serviço indisponível.", "Subscriptions: saved videos · service unavailable.")
                    : Ui.tr("Inscrições indisponíveis no momento.", "Subscriptions are currently unavailable.");
            else subscriptionsLine = count > 0
                    ? Ui.tr("Inscrições: " + count + " vídeos e lives recentes.", "Subscriptions: " + count + " recent videos and streams.")
                    : Ui.tr("Inscrições: nenhum vídeo recente.", "Subscriptions: no recent videos.");
            // The server adapts subscription cadence to quota; metric TTL must not age this snapshot.
            subscriptionsTimestamp = dataTimestamp(recs.optLong("recommendationsAt"), recs.optBoolean("recommendationsStale", true));
        }

        private String dataTimestamp(long at, boolean stale) {
            return at <= 0 ? Ui.tr("Dados ainda indisponíveis", "Data not available yet")
                    : Ui.tr("Dados de ", "Data from ") + new java.text.SimpleDateFormat(Ui.en ? "MMM d, HH:mm" : "dd/MM, HH:mm",
                    Ui.en ? java.util.Locale.US : Ui.PT).format(new java.util.Date(at)) + " · " + ago(at)
                    + (stale ? Ui.tr(" · desatualizados", " · out of date") : "");
        }

        /** Independent status and data age for own metrics and subscription cards. */
        private float drawRecs(Canvas c, float y) {
            float x = LIST_X * k + 30 * k;
            c.drawText(Ui.tr("YOUTUBE · CANAL E INSCRIÇÕES", "YOUTUBE · CHANNEL AND SUBSCRIPTIONS"), x, y, header);
            c.drawText(TextUtils.ellipsize(channelLine, notice, 790 * k, TextUtils.TruncateAt.END).toString(), x, y + 42 * k, notice);
            version.setTextAlign(Paint.Align.LEFT);
            c.drawText(TextUtils.ellipsize(channelTimestamp, notice, 790 * k, TextUtils.TruncateAt.END).toString(), x, y + 78 * k, version);
            c.drawText(TextUtils.ellipsize(subscriptionsLine, notice, 790 * k, TextUtils.TruncateAt.END).toString(), x, y + 118 * k, notice);
            c.drawText(TextUtils.ellipsize(subscriptionsTimestamp, notice, 790 * k, TextUtils.TruncateAt.END).toString(), x, y + 154 * k, version);
            version.setTextAlign(Paint.Align.CENTER);
            return y + 154 * k;
        }

        /** Focused list rows use the shared cyan action color. Returns the focus progress. */
        private float drawRowBackground(Canvas c, int i) {
            float f = Ui.clamp(pop[i].value);
            if (skin.glass) scene.liquid(c, rowRect, 20 * k, theme.SURFACE, .22f, .03f, 16 * k, 10 * k, .7f, 1);
            if (f > 0.01f) {
                float s = 1 + 0.02f * f;
                float cx = rowRect.centerX(), cy = rowRect.centerY();
                tmp.set(cx - rowRect.width() * s / 2, cy - rowRect.height() * s / 2, cx + rowRect.width() * s / 2, cy + rowRect.height() * s / 2);
                float r = skin.radius * k * s;
                tmp.offset(0, 10 * k * f);
                shadow.setColor(Ui.alpha(0xFF000000, 0.4f * f));
                c.drawRoundRect(tmp, r, r, shadow);
                tmp.offset(0, -10 * k * f);
                white.setAlpha(Math.round(255 * f));
                c.drawRoundRect(tmp, r, r, white);
                rowRect.set(tmp);
            }
            return f;
        }

        private float drawComparison(Canvas c, float y) {
            float x = LIST_X * k + 30 * k, colA = LIST_R * k - 220 * k, colB = LIST_R * k - 30 * k;
            c.drawText(Ui.tr("COMPARAÇÃO", "COMPARISON"), x, y, header);
            cellValue.setColor(theme.MUTED);
            c.drawText("Original", colA, y, cellValue);
            c.drawText("Free My TV", colB, y, cellValue);
            cellValue.setColor(theme.SECONDARY);
            JSONObject metrics = state.optJSONObject("metrics");
            JSONObject a = metrics == null ? null : metrics.optJSONObject(HomeMode.ORIGINAL);
            JSONObject b = metrics == null ? null : metrics.optJSONObject(HomeMode.FREE);
            String[][] rows = {{Ui.tr("Botão Início", "Home button"), "homeMs"}, {Ui.tr("Memória livre", "Free memory"), "memAvailableMB"},
                    {Ui.tr("Memória do Início", "Home screen memory"), "homePssMB"}};
            for (int i = 0; i < rows.length; i++) {
                float base = y + (46 + 40 * i) * k;
                c.drawText(rows[i][0], x, base, cellLabel);
                c.drawText(metric(a, rows[i][1]), colA, base, cellValue);
                c.drawText(metric(b, rows[i][1]), colB, base, cellValue);
            }
            return y + (46 + 40 * rows.length) * k;
        }

        private void drawNotices(Canvas c, float y) {
            float x = LIST_X * k + 30 * k;
            c.drawText(Ui.tr("AVISOS", "NOTICES"), x, y, header);
            JSONArray notices = state.optJSONArray("notices");
            int shown = 0;
            for (int i = 0; notices != null && i < notices.length() && shown < 2; i++) {
                JSONObject o = notices.optJSONObject(i);
                if (o == null) continue;
                String line = ago(o.optLong("at")) + " · " + o.optString("text");
                c.drawText(TextUtils.ellipsize(line, notice, 790 * k, TextUtils.TruncateAt.END).toString(), x, y + (42 + 38 * shown) * k, notice);
                shown++;
            }
            if (shown == 0) c.drawText(Ui.tr("Nenhum ainda.", "None yet."), x, y + 42 * k, notice);
        }

        /** Home screen choice: Free My TV or the original, with a check on the one in use. */
        private void drawChoice(Canvas c) {
            Paint heading = Ui.text(fonts.displaySemibold, 34 * k, theme.TEXT);
            c.drawText(Ui.tr("Início", "Home Screen"), LIST_X * k + 30 * k, (LIST_TOP - 24) * k, heading);
            String[][] options = {{"Free My TV", Ui.tr("Sem anúncios, com a tela de descanso nova", "No ads, with the new screensaver")},
                    {"Original", Ui.tr("O Início de fábrica da TV", "The TV's factory home screen")}};
            int current = freeActive() ? 0 : 1;
            for (int i = 0; i < 2; i++) {
                float y = (LIST_TOP + 20 + i * (CHOICE_H + ROW_GAP)) * k;
                rowRect.set(LIST_X * k, y, LIST_R * k, y + CHOICE_H * k);
                float f = drawRowBackground(c, i);
                rowLabel.setColor(blend(theme.TEXT, theme.ON_FOCUS, f));
                rowSub.setColor(blend(theme.SECONDARY, theme.ON_FOCUS, f));
                c.drawText(options[i][0], rowRect.left + 30 * k, rowRect.top + 44 * k, rowLabel);
                c.drawText(options[i][1], rowRect.left + 30 * k, rowRect.top + 80 * k, rowSub);
                if (i == current) {
                    float cw = Symbols.width(getContext(), "check", 26 * k);
                    Symbols.draw(getContext(), c, "check", rowRect.right - 30 * k - cw / 2, rowRect.centerY(), 26 * k, blend(theme.TEXT, theme.ON_FOCUS, f));
                }
            }
            Paint hint = Ui.text(fonts.regular, 23 * k, theme.SECONDARY);
            c.drawText(Ui.tr("A troca leva uns segundos e a tela pisca nas medições.",
                    "Switching takes a few seconds; the screen blinks while it measures."), LIST_X * k + 30 * k,
                    (LIST_TOP + 20 + 2 * (CHOICE_H + ROW_GAP) + 40) * k, hint);
        }

        private static int blend(int a, int b, float f) {
            int aa = a >>> 24, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
            int ba = b >>> 24, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
            return (Math.round(aa + (ba - aa) * f) << 24) | (Math.round(ar + (br - ar) * f) << 16)
                    | (Math.round(ag + (bg - ag) * f) << 8) | Math.round(ab + (bb - ab) * f);
        }

        private static String metric(JSONObject m, String key) {
            if (m == null || !m.has(key)) return "—";
            long v = m.optLong(key);
            if (key.equals("homeMs")) return v + " ms";
            if (key.equals("memAvailableMB") && v >= 1024) return String.format(Ui.en ? java.util.Locale.US : Ui.PT, "%.2f GB", v / 1024.0);
            return v + " MB";
        }

        private static String ago(long at) {
            long minutes = Math.max(0, (System.currentTimeMillis() - at) / 60_000);
            if (minutes < 1) return Ui.tr("agora", "now");
            if (minutes < 60) return Ui.tr("há " + minutes + " min", minutes + " min ago");
            if (minutes < 48 * 60) return Ui.tr("há " + (minutes / 60) + " h", (minutes / 60) + " h ago");
            return Ui.tr("há " + (minutes / 1440) + " dias", (minutes / 1440) + " days ago");
        }

        private static String versionName(Context c) {
            try {
                return "Free My TV " + c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
            } catch (android.content.pm.PackageManager.NameNotFoundException e) {
                return "Free My TV";
            }
        }

        boolean onKey(KeyEvent e) {
            boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
            switch (e.getKeyCode()) {
                case KeyEvent.KEYCODE_DPAD_UP:
                    if (down && focus > 0) focus--;
                    invalidate();
                    spoken.focusMoved();
                    return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    if (down && focus < rowCount() - 1) focus++;
                    invalidate();
                    spoken.focusMoved();
                    return true;
                case KeyEvent.KEYCODE_DPAD_LEFT:
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_NUMPAD_ENTER:
                    if (down) {
                        if (e.getRepeatCount() == 0) okDown = true;
                    } else {
                        if (okDown && !e.isCanceled() && spoken.keyClick()) activate();
                        okDown = false;
                    }
                    return true;
                case KeyEvent.KEYCODE_BACK:
                    if (screen == MAIN) return false;   // leaves the settings
                    if (down) {
                        if (e.getRepeatCount() == 0) backDown = true;
                    } else {
                        if (backDown && !e.isCanceled()) {
                            focus = screen == SKIN_CHOICE ? 1 : 0;
                            screen = MAIN;
                        }
                        backDown = false;
                    }
                    invalidate();
                    spoken.focusMoved();
                    return true;
                default:
                    return false;
            }
        }

        private static String skinName(Skin option) {
            return option.label;
        }

        private void refreshAppearance() {
            Skin selected = SkinPreferences.load(getContext());
            boolean dark = selected.isNight(data.isNight(System.currentTimeMillis()));
            if (selected == skin && dark == night) return;
            skin = selected;
            night = dark;
            fonts = Ui.fonts(getContext(), skin);
            skin.apply(theme, dark ? 1 : 0);
            HomeData.Weather wx = data.weather;
            Shaders.sky(scene.palette, System.currentTimeMillis(), wx.sunrise, wx.sunset);
            scene.applyPalette();
            if (w > 0) onSizeChanged(w, h, w, h);
            invalidate();
        }

        private void drawSkins(Canvas c) {
            c.drawText(Ui.tr("Aparência", "Appearance"), LIST_X * k + 30 * k, (LIST_TOP - 24) * k, rowLabel);
            Skin[] options = Skin.values();
            for (int i = 0; i < options.length; i++) {
                rowRect.set(rowBox(i));
                float f = drawRowBackground(c, i);
                rowLabel.setColor(blend(theme.TEXT, theme.ON_FOCUS, f));
                rowSub.setColor(blend(theme.SECONDARY, theme.ON_FOCUS, f));
                c.drawText(skinName(options[i]), rowRect.left + 30 * k, rowRect.top + 44 * k, rowLabel);
                String detail = Ui.tr(options[i].descriptionPt, options[i].descriptionEn);
                c.drawText(detail, rowRect.left + 30 * k, rowRect.top + 80 * k, rowSub);
                if (options[i] == skin) Symbols.draw(getContext(), c, "check", rowRect.right - 43 * k,
                        rowRect.centerY(), 26 * k, blend(theme.TEXT, theme.ON_FOCUS, f));
            }
            rowLabel.setColor(theme.TEXT);
        }

        private void activate() {
            Context c = getContext();
            if (screen == SKIN_CHOICE) {
                SkinPreferences.save(c, Skin.values()[focus]);
                refreshAppearance();
                spoken.readAgain();
            } else if (screen == HOME_CHOICE) {
                boolean wantFree = focus == 0;
                if (wantFree != freeActive() && !busy()) {
                    HomeMode.request(c, wantFree ? HomeMode.FREE : HomeMode.ORIGINAL);
                    pendingAt = SystemClock.uptimeMillis();
                }
                screen = MAIN;
                focus = 0;
            } else if (focus == 0) {
                if (busy()) return;
                screen = HOME_CHOICE;
                focus = freeActive() ? 0 : 1;
            } else if (focus == 1) {
                screen = SKIN_CHOICE;
                focus = skin.ordinal();
            } else if (focus == 2) {
                pause();
                activity.showPreview();
            } else {
                activity.startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }
            for (Spring s : pop) s.snap(0);
            invalidate();
            spoken.focusMoved();
        }
    }
}
