package io.freemytv;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.tv.TvInputManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.Choreographer;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Shared TV home with selectable ViktorKav, Liquid Glass and GTA VI presentation,
 * nine subscription cards across three scrollable rows and seven streaming shortcuts. Cyan outlines identify the remote's focus.
 * The existing drawer, tab navigation, app actions and accessibility tree remain shared.
 * Measurements use a 1920×1080 canvas, scaled by k. Cached layers only redraw when content changes.
 */
final class HomeView extends ViewGroup implements Choreographer.FrameCallback, HomeData.Listener, Recs.Listener {
    // tvOS grid (Human Interface Guidelines): content inside the safe area, 80 px from the sides and 60 from top and
    // bottom; 40 px between items; 7 columns of 217 px (the apps). The shelf glass extends 36 px past the tiles (the
    // same padding on all four sides) and the tile corners are concentric with it (glass radius = radius + padding).
    private static final float MARGIN = 80, CONTENT_R = 1840;
    // Hero, anchored at the bottom (a two-line title grows upward).
    private static final float HERO_TITLE_W = 900;
    // Shelf: tiles with corners concentric with the glass (glass radius = tile radius + padding).
    // Shelf like the tvOS 27 Dock: 5:3 icons (210 × 126) in each brand's color, 48 apart, and the glass bar hugging
    // them with 40 of padding (the focused icon grows 7% without touching its edge).
    private static final float SHELF_PAD = 40, TILE_GAP = 48;
    private static final float TILE_MAX_W = 270;
    private final float TILE_RADIUS, FOCUS_GROW, GRID_RADIUS;
    final Skin skin;
    private final Skin.Palette theme = new Skin.Palette();
    private final Ui.Fonts fonts;
    private Bitmap gameWallpaper,gameWallpaperFrom;
    private boolean destroyed;
    private long gameWallpaperFadeAt;
    private final HomeWallpaperCycle gameCycle=new HomeWallpaperCycle();
    private final LaunchCountdownView launchBadge;
    private final XboxHeaderView xboxPanel;
    private int xboxReturnTop;
    private final Runnable wallpaperTick=()->loadGameWallpaper();
    // Tile focus (Apple TV style): it grows from the center and its shadow drops (it "rises" toward the viewer).
    // Corner capsule.
    // Corner capsule: the height and top offset of the tvOS tab bar (68 and 46).
    private static final float CAPSULE_TOP = 46, CAPSULE_H = 68, BUTTON = 56;
    // Bottom drawer (measured with it open; everything moves up by SHIFT).
    private static final float SHIFT = 560, ROW_TITLE = 518, ROW_TOP = 540, ROW_H = 126, CARDS_TOP = 708, CARDS_H = 300;
    // "All Apps" sheet.
    private static final int COLUMNS = 5, VISIBLE_ROWS = 3;
    private static final float GRID_W = 300, GRID_H = 169, GRID_GAP = 40, GRID_ROW = 239, GRID_TOP = 196;
    private static final int SMOKE = TvTheme.FIELD, INK = TvTheme.ON_FOCUS, WHITE = TvTheme.TEXT;
    private static final long TOAST_MS = 6000, FADE_MS = 800;
    private static final int SKY = 0, HERO = 1, STATUS = 2, PLATTER = 3, TILES = 4, DRAWER = 5, SHEET = 6, TOAST = 7;
    private static final int Z_STATUS = 0, Z_HERO = 1, Z_SHELF = 2, Z_DRAWER = 3;
    private static final ExecutorService LOADER = Executors.newSingleThreadExecutor();
    // Light design (the L_ constants): title, tab bar, nine recommendation cards and the shelf.
    // Three columns keep complete thumbnails above two-line titles and metadata.
    private static final float L_TITLE_BASE = 130, L_TABBAR_TOP = 158, L_TABBAR_H = 68;
    private static final float L_BUTTON = 68, L_BUTTON_GAP = 20, L_BUTTON_CY = 103;
    private static final float L_PLATTER_TOP = 814, L_TILE_H = 126;
    private static final int L_INK = 0xFF1D1D1F, L_DIM = 0xFF6E6E73, L_FAINT = 0xFF8E8E93;
    private static final String[] TABS = {"Recentes", "Vídeos", "Lives"};
    private static final String[] TABS_EN = {"Recent", "Videos", "Live"};
    private static final String[] PUBLIC_TABS = {"Recentes", "YouTube", "Trailers"};
    private static final String[] PUBLIC_TABS_EN = {"Recent", "YouTube", "Trailers"};
    private static final String[] PUBLIC_KIND = {null, "favorites", "trailer"};
    private static final String[] TAB_KIND = {null, "video", "live"};
    private static final int Z_TOP = 4, Z_CARDS = 5, Z_XBOX = 6;

    private final Activity activity;
    private final Scene scene = new Scene();
    private final HomeData data;
    private final Recs recs;
    private final Click click;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SharedPreferences ui;
    private final TvInputManager tvInputs;
    private final Spoken spoken = new Spoken(this, new Spoken.Source() {
        @Override public void items(List<Integer> out) { a11yItems(out); }
        @Override public String text(int id) { return a11yText(id); }
        @Override public boolean bounds(int id, Rect out) { return a11yBounds(id, out); }
        @Override public int focused() { return a11yFocused(); }
        @Override public void focus(int id) { a11yFocus(id); }
        @Override public void click(int id) { activate(); }
    });
    private final RectF a11yRect = new RectF();
    private final Layer sky, heroLayer, status, platter, tiles, drawerLayer, sheetLayer, toastLayer;
    private int zone = Z_SHELF;

    // Night look (like Apple's "Automatic" appearance): darker from sunset to sunrise, with a 2 s transition.
    private static final long NIGHT_MS = 2000;
    private boolean nightTarget;
    private float night, nightFrom;     // 0 = day, 1 = night
    private long nightAt;
    private final int[] glassNight = new int[Backdrop.GW * Backdrop.GH], frostNight = new int[Backdrop.FW * Backdrop.FH];
    private final int[] neutralGlassPx = new int[Backdrop.GW * Backdrop.GH], neutralFrostPx = new int[Backdrop.FW * Backdrop.FH];
    private boolean nightPair;          // the glass holds both photos (day and night), blended by `night`
    private Shader nightGradient;

    // At the top: tabs (0 to 2) and icon-only buttons (3 to 5); three large cards below.
    private int tab, topIndex, cardIndex;
    private List<Recs.Pick> cards = new ArrayList<>();
    private final VideoRail<Recs.Pick> videoRail = new VideoRail<>();
    private String railSource = "";
    private final Spring[] topFocus = new Spring[6];
    private final RectF[] topRects = new RectF[6];
    private final Spring[] cardFocus = new Spring[CardGrid.LIMIT];
    private final RectF[] cardRects = new RectF[CardGrid.LIMIT];
    private final List<HomeApps.Item> lightButtons = new ArrayList<>();
    private Paint lTitle, lTab, lTabOn, lCardTitle, lCardMeta, lQuote, lTip, brandLabel;
    private Shader lightGradient;
    private final Backdrop[] cardBackdrops = new Backdrop[CardGrid.LIMIT];
    private final StaticLayout[] cardTitles = new StaticLayout[CardGrid.LIMIT];
    private final String[] cardMeta = new String[CardGrid.LIMIT];
    private String cardRange = "";
    private static final String[] METRIC_SHORT_PT = {"Inscr.", "Views canal", "Views vídeo", "Likes vídeo"};
    private static final String[] METRIC_SHORT_EN = {"Subs.", "Channel views", "Video views", "Video likes"};
    private final String[] metricLabels = new String[4], metricValues = new String[4], metricShort = new String[4];
    private String metricsSource = "", drawerSource = "", emptyTitle = "", emptyDetail = "";

    // Shelf
    private List<HomeApps.Item> shelf = new ArrayList<>();
    private Spring[] tileFocus = new Spring[0];
    private RectF[] tileRects = new RectF[0];
    private final Map<String, Bitmap> crispLogos = new HashMap<>();   // logos already sized for the focused tile
    /** Each app's tile like its Apple TV icon: brand colors (top, bottom) and logo (0 = as is, 1 = white, 2 = dark). */
    private static final Map<String, int[]> TILE_STYLE = new HashMap<>();
    static {
        TILE_STYLE.put("netflix", new int[] {0xFF0A0A0A, 0xFF000000, 0});
        TILE_STYLE.put("youtube", new int[] {0xFF1C1C1E, 0xFF09090A, 0});
        TILE_STYLE.put("globoplay", new int[] {0xFFFF8A1F, 0xFFFF2D5A, 1});
        TILE_STYLE.put("prime", new int[] {0xFF2AA8FF, 0xFF0A68D4, 1});
        TILE_STYLE.put("disney", new int[] {0xFF173584, 0xFF08143F, 0});
        TILE_STYLE.put("max", new int[] {0xFF5C30E8, 0xFF221684, 0});
        TILE_STYLE.put("appletv", new int[] {0xFF1C1C1E, 0xFF000000, 0});
        TILE_STYLE.put("twitch", new int[] {0xFF9146FF, 0xFF6022B8, 1});
        TILE_STYLE.put("jellyfin", new int[] {0xFF252539, 0xFF10101D, 0});
        TILE_STYLE.put("stremio", new int[] {0xFF8464F4, 0xFF4D35AA, 1});
    }
    private final android.graphics.PorterDuffColorFilter whiteLogo =
            new android.graphics.PorterDuffColorFilter(0xFFFFFFFF, android.graphics.PorterDuff.Mode.SRC_IN);
    private final RectF platterRect = new RectF();
    private int shelfIndex;

    // Corner capsule
    private List<HomeApps.Item> statusItems = new ArrayList<>();
    private Spring[] statusFocus = new Spring[0];
    private RectF[] statusRects = new RectF[0];
    private final RectF capsuleRect = new RectF();
    private float capsuleInfoW;
    private int statusIndex;

    // Hero and background
    private List<Recs.Pick> picks = new ArrayList<>();
    private int pickIndex, heroSlide = 1;
    private Hero hero, heroFrom;
    private long heroFadeAt, bgFadeAt;
    private final Spring heroFocus = new Spring(0.28f, 0.85f, 0);
    private final RectF heroButton = new RectF();
    private Backdrop bgFrom, bgTo;     // null = gradient (no photo)
    private final int[] frostMix = new int[Backdrop.FW * Backdrop.FH];

    // Bottom drawer
    private List<HomeApps.Item> drawerItems = new ArrayList<>();
    private int drawerInputs;          // how many leading items are inputs (the rest are shortcuts)
    private Spring[] drawerFocus = new Spring[0];
    private RectF[] drawerRects = new RectF[0];
    private final RectF weatherCard = new RectF(), metricsCard = new RectF();
    private final Spring drawer = new Spring(0.46f, 0.92f, 0);
    private boolean drawerOpen;
    private int drawerIndex;

    // "All Apps" sheet
    private List<HomeApps.Item> others = new ArrayList<>();
    private Spring[] gridFocus = new Spring[0];
    private String[] gridLabels;
    private final Spring sheet = new Spring(0.38f, 0.9f, 0);
    private final Spring scroll = new Spring(0.34f, 1f, 0);
    private final RectF focusedCell = new RectF();
    private boolean sheetOpen;
    private int gridIndex;

    // Toasts
    private final ArrayDeque<String> toasts = new ArrayDeque<>();
    private StaticLayout toast;
    private long toastAt;

    // Frames
    private boolean running, tilesDirty, statusDirty, heroDirty, drawerDirty, gridDirty, motionDirty = true;
    private boolean drawerWasMoving;
    private long lastNanos, resumedAt, lastStep;
    private int w, h;
    private float k = 1;
    private String clockText = "";
    private long clockMinute = -1;
    private boolean okDown, backDown;

    private Paint labelPaint, metaPaint, clockPaint, buttonPaint, capsuleText, tipPaint, quotePaint, staleQuote;
    private Paint rowTitle, drawerLabel, cardTitle, cardText, cardDim, cardDimRight, bigTemp, hourPaint, hourTemp;
    private Paint metricValuePaint, sheetTitle;
    private TextPaint titlePaint, gridLabel, toastPaint;
    private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint imagePaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowSoft = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowDeep = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final LinearGradient neonGradient = new LinearGradient(0,0,1,1,
            new int[]{0xFFFF68BF,0xFFC9A0FF,0xFFFFD6A3},null,Shader.TileMode.CLAMP);
    private final android.graphics.Matrix neonMatrix = new android.graphics.Matrix();
    private final Paint neonRim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint veil = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tileFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF tmp = new RectF(), cell = new RectF(), screen = new RectF();

    /** What the hero shows: a recommendation or, without any, the date, the time and the weather. */
    private static final class Hero {
        String label = "", title = "", meta = "";
        boolean clock, button;
        int dots, dot;
        StaticLayout titleLayout;

        boolean sameText(Hero o) {
            return o != null && clock == o.clock && label.equals(o.label) && title.equals(o.title) && meta.equals(o.meta);
        }
    }

    /** One layer of the screen. It draws in full-screen coordinates: the glass needs each pixel's real position. */
    private final class Layer extends View {
        private final int kind;

        Layer(Context c, int kind) {
            super(c);
            this.kind = kind;
        }

        @Override protected void onDraw(Canvas c) {
            if (labelPaint == null) return;
            c.translate(-getLeft(), -getTop());
            // The layer may be shifted (bottom drawer): the glass reads the background from where it really is. The
            // drawer and the top buttons are always drawn as if resting in place (they are only visible there and are
            // not redrawn while they move).
            scene.setOffset(0, kind == DRAWER || kind == STATUS ? 0 : getTranslationY());
            switch (kind) {
                case SKY: drawSky(c); break;
                case HERO: drawLightTop(c); break;
                case STATUS: drawLightButtons(c); break;
                case PLATTER: drawPlatter(c); break;
                case TILES: drawTiles(c); break;
                case DRAWER: drawDrawer(c); break;
                case SHEET: drawSheet(c); break;
                default: drawToast(c); break;
            }
            scene.setOffset(0, 0);
        }
    }

    private final TvInputManager.TvInputCallback inputCallback = new TvInputManager.TvInputCallback() {
        @Override public void onInputStateChanged(String inputId, int state) { reload(); }
        @Override public void onInputAdded(String inputId) { reload(); }
        @Override public void onInputRemoved(String inputId) { reload(); }
    };

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            data.refreshIfStale();
            recs.refreshIfStale();
            if(xboxPanel!=null)xboxPanel.refreshIfStale();
            checkNotices();
            updatePalette();
            checkNight(true);
            updatePicks();      // refresh the source age and cached card text
            handler.postDelayed(this, 15_000);
        }
    };

    HomeView(Activity a) {
        super(a);
        activity = a;
        skin = SkinPreferences.load(a);
        fonts = Ui.fonts(a, skin);
        TILE_RADIUS = skin.tileRadius;
        FOCUS_GROW = skin.focusGrow;
        GRID_RADIUS = skin.radius;
        skin.apply(theme, 0);
        data = HomeData.get(a);
        recs = Recs.get(a);
        click = new Click(a);
        ui = a.getSharedPreferences("home-ui", Context.MODE_PRIVATE);
        tvInputs = (TvInputManager) a.getSystemService(Context.TV_INPUT_SERVICE);
        setFocusable(true);
        sky = new Layer(a, SKY);
        heroLayer = new Layer(a, HERO);
        status = new Layer(a, STATUS);
        platter = new Layer(a, PLATTER);
        tiles = new Layer(a, TILES);
        drawerLayer = new Layer(a, DRAWER);
        sheetLayer = new Layer(a, SHEET);
        toastLayer = new Layer(a, TOAST);
        launchBadge=skin==Skin.GTA_VI?new LaunchCountdownView(a,fonts):null;
        xboxPanel=skin==Skin.GTA_VI?new XboxHeaderView(a,fonts):null;
        // Hardware layers on the GPU: only the one that changed is redrawn; moving, fading and scaling stay cheap.
        for (View v : new View[] {heroLayer, status, platter, tiles, drawerLayer, sheetLayer}) v.setLayerType(LAYER_TYPE_HARDWARE, null);
        for (View v : new View[] {sky, heroLayer, status, platter, tiles, drawerLayer, sheetLayer, toastLayer}) {
            v.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);   // TalkBack reads the items (Spoken)
            addView(v);
        }
        if(xboxPanel!=null)addView(xboxPanel,2);
        if(launchBadge!=null)addView(launchBadge,2); // above the hero, below buttons/drawers/sheets
        setContentDescription("Free My TV");
        drawerLayer.setVisibility(INVISIBLE);
        for (int i = 0; i < 6; i++) {
            topFocus[i] = new Spring(0.26f, 0.85f, 0);
            topRects[i] = new RectF();
        }
        for (int i = 0; i < CardGrid.LIMIT; i++) {
            cardFocus[i] = new Spring(0.32f, 0.78f, 0);
            cardRects[i] = new RectF();
        }
        makeLightButtons();
        recs.setLight(true);
        checkNight(false);
        sheetLayer.setVisibility(INVISIBLE);
        scene.setMotion(0.6f, 0f);
        updatePalette();
        // First time: right away (a cold start opens with the apps already there); missing logos come from reload().
        setShelf(HomeApps.shelf(a, false));
        setStatusItems(statusList(a));
        setDrawerItems(drawerList(a));
    }

    // MARK: - Lifecycle (called by HomeActivity)

    void resume() {
        if (running) return;
        running = true;
        startGameWallpaper();
        if(launchBadge!=null)launchBadge.resume();
        if(xboxPanel!=null)xboxPanel.resume();
        checkNight(false);
        resumedAt = SystemClock.uptimeMillis();
        lastNanos = 0;
        lastStep = 0;
        data.addListener(this);
        recs.addListener(this);
        data.refreshIfStale();
        recs.refreshIfStale();
        if (tvInputs != null) tvInputs.registerCallback(inputCallback, handler);
        handler.postDelayed(tick, 15_000);
        checkNotices();
        reload();
        updatePalette();
        updatePicks();
        if (sheetOpen) closeSheet();
        sheet.snap(sheet.target);
        motionDirty = true;
        invalidateAll();
        Choreographer.getInstance().postFrameCallback(this);
        spoken.readAgain();
    }

    void pause() {
        if (!running) return;
        running = false;
        Choreographer.getInstance().removeFrameCallback(this);
        handler.removeCallbacks(tick);
        stopGameWallpaper();
        if(launchBadge!=null)launchBadge.pause();
        if(xboxPanel!=null)xboxPanel.pause();
        data.removeListener(this);
        recs.removeListener(this);
        if (tvInputs != null) tvInputs.unregisterCallback(inputCallback);
    }

    void destroy() {
        pause();
        destroyed = true;
        stopGameWallpaper();
        Bitmap gone=gameWallpaper,old=gameWallpaperFrom;
        gameWallpaper=null;gameWallpaperFrom=null;gameWallpaperFadeAt=0;
        retireWallpaper(gone);retireWallpaper(old);
        click.release();
    }

    private void startGameWallpaper(){
        if(skin!=Skin.GTA_VI||!running||destroyed||sheetOpen)return;
        gameCycle.resume(SystemClock.uptimeMillis());
        loadGameWallpaper();
    }
    private void stopGameWallpaper(){gameCycle.pause();handler.removeCallbacks(wallpaperTick);}
    private void scheduleGameWallpaper(){
        handler.removeCallbacks(wallpaperTick);
        long delay=gameCycle.delay(SystemClock.uptimeMillis());
        if(running&&!destroyed&&!sheetOpen&&delay>=0)handler.postDelayed(wallpaperTick,delay);
    }
    private void loadGameWallpaper() {
        if(skin!=Skin.GTA_VI||!running||destroyed||sheetOpen)return;
        final HomeWallpaperCycle.Request request=gameCycle.request(SystemClock.uptimeMillis());
        if(request==null){scheduleGameWallpaper();return;}
        final android.content.res.AssetManager assets=activity.getApplicationContext().getAssets();
        LOADER.execute(()->{
            if(!gameCycle.current(request))return;
            Bitmap loaded=null;
            try{loaded=Wallpaper.home(assets,request.asset);}
            catch(Exception|OutOfMemoryError e){AppLog.w("game wallpaper decode unavailable");}
            final Bitmap ready=loaded;
            handler.post(()->{
                if(destroyed||!gameCycle.complete(request,ready!=null,SystemClock.uptimeMillis())){
                    if(ready!=null)ready.recycle();return;
                }
                if(ready!=null){
                    retireWallpaper(gameWallpaperFrom);
                    gameWallpaperFrom=gameWallpaper;gameWallpaper=ready;
                    gameWallpaperFadeAt=gameWallpaperFrom==null?0:SystemClock.uptimeMillis();
                    sky.invalidate();
                }
                scheduleGameWallpaper();
            });
        });
    }
    private void retireWallpaper(Bitmap image){if(image!=null)handler.postDelayed(image::recycle,1000);}
    private boolean tickGameWallpaper(long now){
        if(gameWallpaperFadeAt==0)return false;
        if(now-gameWallpaperFadeAt>=FADE_MS){
            gameWallpaperFadeAt=0;
            Bitmap old=gameWallpaperFrom;gameWallpaperFrom=null;retireWallpaper(old);
        }
        return true;
    }

    /** Starting state (Home pressed while the home screen is showing): first app focused, drawer and sheet closed. */
    void reset(boolean animated) {
        zone = shelfZone();
        shelfIndex = 0;
        cardIndex = 0;
        sheetOpen = false;
        startGameWallpaper();
        drawerOpen = false;
        if (animated) {
            sheet.target = 0;
            drawer.target = 0;
        } else {
            sheet.snap(0);
            drawer.snap(0);
        }
        if (pickIndex != 0 && !picks.isEmpty()) {
            pickIndex = 0;
            updatePicks();
        }
        if (tab != 0) selectTab(0);
        else { videoRail.rewind(); updateCards(); }
        retarget(!animated);
        motionDirty = true;
    }

    /** The three corner buttons, with their names in the current language. */
    private void makeLightButtons() {
        lightButtons.clear();
        lightButtons.add(HomeApps.action(HomeApps.LIVE_TV, "live", Ui.tr("TV aberta", "Live TV"), "live_tv"));
        lightButtons.add(HomeApps.action(HomeApps.INPUTS, "inputs", Ui.tr("Entradas HDMI", "HDMI Inputs"), "hdmi"));
        lightButtons.add(HomeApps.action(HomeApps.SETTINGS, "settings", Ui.tr("Configurações", "Settings"), "settings"));
    }

    private String[] tabs() {
        return recs.publicMode() ? (Ui.en ? PUBLIC_TABS_EN : PUBLIC_TABS) : (Ui.en ? TABS_EN : TABS);
    }
    private String tabKind() { return recs.publicMode() ? PUBLIC_KIND[tab] : TAB_KIND[tab]; }
    private int shelfZone() {
        if(shelf.isEmpty()) { topIndex=5; return Z_TOP; }
        return Z_SHELF;
    }

    @Override public void onData() {
        updatePalette();
        updateMetrics();
        checkNight(true);
        layoutStatus();
        heroDirty = statusDirty = drawerDirty = true;
        platter.invalidate();
    }

    @Override public void onRecs() {
        updateMetrics();
        layoutLight();
        updatePicks();
    }

    private void invalidateAll() {
        for (View v : new View[] {sky, heroLayer, status, platter, tiles, drawerLayer}) v.invalidate();
    }

    // MARK: - Size and layers

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec), height = MeasureSpec.getSize(heightSpec);
        float kk = width / 1920f;
        measure(sky, width, height);
        measure(heroLayer, width, Math.round(810 * kk));
        if(launchBadge!=null)measure(launchBadge,Math.round(560*kk),Math.round(92*kk));
        if(xboxPanel!=null)measure(xboxPanel,Math.round(650*kk),Math.round(118*kk));
        measure(status, Math.round(1160 * kk), Math.round(240 * kk));
        // Sized to what they draw (the glass and its shadow; the grown tiles and their shadows): smaller layers are
        // cheaper for the GPU to composite on every frame of the drawer animation.
        measure(platter, width, Math.round(320 * kk));
        measure(tiles, width, Math.round(270 * kk));
        measure(drawerLayer, width, Math.round(600 * kk));
        measure(sheetLayer, width, height);
        measure(toastLayer, Math.round(1000 * kk), Math.round(220 * kk));
        setMeasuredDimension(width, height);
    }

    private static void measure(View v, int width, int height) {
        v.measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY));
    }

    @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int width = r - l, height = b - t;
        float kk = width / 1920f;
        sky.layout(0, 0, width, height);
        place(heroLayer, 0, 0);
        if(launchBadge!=null){
            float titleWidth=lTitle==null?220*kk:lTitle.measureText("GTA VI");
            place(launchBadge,Math.round(MARGIN*kk+titleWidth+36*kk),Math.round(60*kk));
        }
        if(xboxPanel!=null)place(xboxPanel,Math.round(Math.min(launchBadge.getRight()+24*kk,922*kk)),Math.round(38*kk));
        place(status, width - status.getMeasuredWidth(), 0);
        place(platter, 0, Math.round(750 * kk));
        place(tiles, 0, Math.round(790 * kk));
        place(drawerLayer, 0, Math.round(470 * kk));
        sheetLayer.layout(0, 0, width, height);
        sheetLayer.setPivotX(width / 2f);
        sheetLayer.setPivotY(height / 2f);
        place(toastLayer, (width - toastLayer.getMeasuredWidth()) / 2, 0);
    }

    private static void place(View v, int x, int y) {
        v.layout(x, y, x + v.getMeasuredWidth(), y + v.getMeasuredHeight());
    }

    @Override protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        w = width;
        h = height;
        k = w / 1920f;
        screen.set(0, 0, w, h);
        scene.setSize(w, h);
        makePaints();
        gridLabels = null;
        clockMinute = -1;
        updateClock();
        layoutShelf();
        layoutStatus();
        layoutDrawer();
        layoutLight();
        hero = null;
        heroFrom = null;
        updatePicks();
        motionDirty = true;
    }

    private void makePaints() {
        labelPaint = Ui.text(fonts.medium, 25 * k, 0xC7FFFFFF);
        labelPaint.setLetterSpacing(0.1f);
        titlePaint = new TextPaint(Ui.text(fonts.displayMedium, 76 * k, 0xFFFFFFFF));
        titlePaint.setLetterSpacing(0.005f);
        metaPaint = Ui.text(fonts.medium, 29 * k, 0xD1FFFFFF);
        metaPaint.setLetterSpacing(0.014f);
        clockPaint = fonts.numbers(fonts.thin, 176 * k, 0xFFFFFFFF);
        clockPaint.setLetterSpacing(-0.01f);
        for (Paint p : new Paint[] {labelPaint, titlePaint, metaPaint, clockPaint}) p.setShadowLayer(22 * k, 0, 2 * k, 0x59000000);
        lTitle = Ui.text(fonts.displaySemibold, 52 * k, theme.TEXT);
        lTitle.setLetterSpacing(0.004f);
        lTab = Ui.text(fonts.medium, 30 * k, L_DIM);
        lTabOn = Ui.text(fonts.semibold, 30 * k, L_INK);
        lCardTitle = Ui.text(fonts.medium, 31 * k, theme.TEXT);
        lCardMeta = Ui.text(fonts.regular, 25 * k, theme.SECONDARY);
        lQuote = fonts.numbers(fonts.regular, 19 * k, theme.SECONDARY);
        brandLabel = Ui.text(fonts.mono, 17 * k, theme.MUTED);
        lTip = Ui.text(fonts.semibold, 25 * k, L_INK);
        lTip.setTextAlign(Paint.Align.CENTER);
        lightGradient = null;
        buttonPaint = Ui.text(fonts.semibold, 29 * k, INK);
        capsuleText = fonts.numbers(fonts.medium, 29 * k, 0xF2FFFFFF);
        tipPaint = Ui.text(fonts.semibold, 25 * k, 0xF2FFFFFF);
        tipPaint.setTextAlign(Paint.Align.CENTER);
        tipPaint.setShadowLayer(16 * k, 0, 1 * k, 0x99000000);
        // Public channel counts, compact enough for the tab row.
        quotePaint = fonts.numbers(fonts.regular, 21 * k, 0xB8FFFFFF);
        quotePaint.setShadowLayer(14 * k, 0, 1 * k, 0x99000000);
        staleQuote = Ui.text(fonts.medium, 21 * k, 0x99FFFFFF);
        staleQuote.setTextAlign(Paint.Align.RIGHT);
        rowTitle = Ui.text(fonts.mono, 23 * k, theme.SECONDARY);
        drawerLabel = Ui.text(fonts.medium, 23 * k, 0xEBFFFFFF);
        drawerLabel.setTextAlign(Paint.Align.CENTER);
        cardTitle = Ui.text(fonts.mono, 23 * k, theme.SECONDARY);
        cardText = Ui.text(fonts.medium, 29 * k, 0xF2FFFFFF);
        cardDim = fonts.numbers(fonts.medium, 23 * k, 0xADFFFFFF);
        cardDimRight = Ui.text(fonts.medium, 21 * k, 0x99FFFFFF);
        cardDimRight.setTextAlign(Paint.Align.RIGHT);
        bigTemp = fonts.numbers(fonts.light, 100 * k, 0xFFFFFFFF);
        hourPaint = fonts.numbers(fonts.medium, 22 * k, 0xADFFFFFF);
        hourPaint.setTextAlign(Paint.Align.CENTER);
        hourTemp = fonts.numbers(fonts.medium, 26 * k, 0xF2FFFFFF);
        hourTemp.setTextAlign(Paint.Align.CENTER);
        metricValuePaint = fonts.numbers(fonts.medium, 26 * k, 0xF2FFFFFF);
        metricValuePaint.setTextAlign(Paint.Align.RIGHT);
        sheetTitle = Ui.text(fonts.displaySemibold, 40 * k, 0xFFFFFFFF);
        sheetTitle.setTextAlign(Paint.Align.CENTER);
        gridLabel = new TextPaint(Ui.text(fonts.medium, 24 * k, 0x99FFFFFF));
        gridLabel.setTextAlign(Paint.Align.CENTER);
        toastPaint = new TextPaint(Ui.text(fonts.medium, 26 * k, 0xF2FFFFFF));
        shadow.setMaskFilter(new BlurMaskFilter(26 * k, BlurMaskFilter.Blur.NORMAL));
        shadowSoft.setMaskFilter(new BlurMaskFilter(12 * k, BlurMaskFilter.Blur.NORMAL));
        shadowDeep.setMaskFilter(new BlurMaskFilter(30 * k, BlurMaskFilter.Blur.NORMAL));
        halo.setMaskFilter(new BlurMaskFilter(22 * k, BlurMaskFilter.Blur.NORMAL));
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(2 * k);
        neonRim.setStyle(Paint.Style.STROKE);
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(3 * k);
    }

    // MARK: - Frames: 60 per second while something moves; nothing is redrawn when still

    @Override public void doFrame(long frameTimeNanos) {
        if (!running) return;
        float dt = lastNanos == 0 ? 1 / 60f : Math.min(0.05f, (frameTimeNanos - lastNanos) / 1e9f);
        lastNanos = frameTimeNanos;
        long up = SystemClock.uptimeMillis();

        boolean tilesMoving = step(tileFocus, dt);
        boolean statusMoving = step(statusFocus, dt);
        boolean heroMoving = heroFocus.step(dt);
        boolean topMoving = step(topFocus, dt), cardsMoving = step(cardFocus, dt);
        if (topMoving) status.invalidate();
        heroMoving |= topMoving | cardsMoving;
        boolean drawerItemsMoving = step(drawerFocus, dt);
        boolean gridMoving = step(gridFocus, dt) | scroll.step(dt);
        boolean drawerMoving = drawer.step(dt);
        boolean sheetMoving = sheet.step(dt);
        boolean toastFading = tickToast(up);
        boolean heroFading = tickHeroFade(up);
        boolean bgFading = tickBackgroundFade(up);
        boolean gameFading=tickGameWallpaper(up);
        boolean nightMoving = tickNight(up);

        if (drawerMoving || sheetMoving || motionDirty) updateMotion();
        // Opening and closing the drawer only moves the cached layers: redrawing the glass on every frame made the TV
        // drop frames (measured: ~50 ms of GPU per frame). The app tiles have no glass; the top buttons fade out as
        // they rise; the drawer is drawn resting in place; the glass shelf is redrawn once the drawer stops, so the
        // glass shows the background where it ended up.
        if (tilesMoving || tilesDirty) tiles.invalidate();
        if (statusMoving || statusDirty || bgFading) status.invalidate();
        if (heroMoving || heroDirty || heroFading || (skin.glass && bgFading)) heroLayer.invalidate();
        if (drawerItemsMoving || drawerDirty || bgFading) drawerLayer.invalidate();
        if (gridMoving || gridDirty || (skin.glass && bgFading)) sheetLayer.invalidate();
        if (drawerMoving || bgFading || gameFading) sky.invalidate();
        if (bgFading || (drawerWasMoving && !drawerMoving)) platter.invalidate();
        drawerWasMoving = drawerMoving;
        tilesDirty = statusDirty = heroDirty = drawerDirty = gridDirty = motionDirty = false;
        if (updateClock()) {
            layoutStatus();
            status.invalidate();
            if (hero != null && hero.clock) {
                refreshHero(false);
                heroLayer.invalidate();
            }
        }

        // Busy: something is moving, or the sheet or the drawer is open.
        boolean busy = tilesMoving || statusMoving || heroMoving || drawerItemsMoving || gridMoving || drawerMoving
                || sheetMoving || toastFading || heroFading || bgFading || nightMoving || sheetOpen || sheet.value > 0.001f
                || drawerOpen || drawer.value > 0.001f;
        Choreographer.getInstance().postFrameCallback(this);
    }

    private static boolean step(Spring[] springs, float dt) {
        boolean moving = false;
        for (Spring s : springs) moving |= s.step(dt);
        return moving;
    }

    /** Drawer and sheet: the layers' positions and opacity (without redrawing their content). */
    private void updateMotion() {
        float d = drawer.value, dc = Ui.clamp(d), s = Ui.clamp(sheet.value);
        float home = 1 - s, top = home * (1 - smoothstep(0, 0.32f, dc));
        float shift = SHIFT * k;
        float lift = -d * shift;
        show(heroLayer, top, lift);
        if(launchBadge!=null)launchBadge.homeTransform(top,lift);
        if(xboxPanel!=null)xboxPanel.homeTransform(top,lift);
        show(status, top, lift);
        show(platter, home, lift);
        show(tiles, home, lift);
        float da = home * smoothstep(0.1f, 0.6f, dc);
        drawerLayer.setTranslationY((1 - d) * shift);
        drawerLayer.setAlpha(da);
        drawerLayer.setVisibility(da > 0.002f ? VISIBLE : INVISIBLE);
        sheetLayer.setVisibility(s > 0.001f || sheetOpen ? VISIBLE : INVISIBLE);
        sheetLayer.setAlpha(s);
        float scale = 1.04f - 0.04f * s;
        sheetLayer.setScaleX(scale);
        sheetLayer.setScaleY(scale);
    }

    private static void show(View v, float alpha, float translationY) {
        v.setAlpha(alpha);
        v.setTranslationY(translationY);
        v.setVisibility(alpha > 0.002f ? VISIBLE : INVISIBLE);
    }

    private boolean updateClock() {
        long now = System.currentTimeMillis();
        long minute = now / 60_000;
        if (minute == clockMinute || clockPaint == null) return false;
        clockMinute = minute;
        clockText = Ui.clock(now);
        return true;
    }

    private void updatePalette() {
        HomeData.Weather wx = data.weather;
        Shaders.sky(scene.palette, System.currentTimeMillis(), wx.sunrise, wx.sunset);
        scene.applyPalette();
    }

    // MARK: - Recommendations: hero and background

    private Recs.Pick currentPick() {
        return picks.isEmpty() ? null : picks.get(Math.min(pickIndex, picks.size() - 1));
    }

    /** Recent videos: the cards and the background image (called when Recs notifies and every 15 s). */
    private void updatePicks() {
        if (labelPaint == null) return;
        updateMetrics();
        updateCards();
    }

    private static boolean samePicks(List<Recs.Pick> a, List<Recs.Pick> b) {
        if (a.size() != b.size()) return false;
        for (int i = 0; i < a.size(); i++) if (!Recs.key(a.get(i)).equals(Recs.key(b.get(i)))) return false;
        return true;
    }

    /**
     * Rebuilds the hero. With `animate`, a different title slides in while the previous one slides out; details that
     * arrive later (genre, runtime) just appear.
     */
    private void refreshHero(boolean animate) {
        Hero next = makeHero();
        if (next.sameText(hero) && hero.dots == next.dots && hero.dot == next.dot && hero.button == next.button) return;
        boolean other = hero != null && (hero.clock != next.clock || !hero.title.equals(next.title));
        if (animate && other) {
            heroFrom = hero;
            heroFadeAt = SystemClock.uptimeMillis();
        }
        boolean layoutChanged = hero == null || hero.clock != next.clock;
        hero = next;
        heroDirty = true;
        if (layoutChanged) layoutStatus();
    }

    private Hero makeHero() {
        Hero h = new Hero();
        Recs.Pick p = currentPick();
        if (p == null) {
            h.clock = true;
            h.label = Ui.date(System.currentTimeMillis()).toUpperCase(Ui.en ? java.util.Locale.US : Ui.PT);
            return h;
        }
        h.label = Recs.periodLabel();
        h.title = p.title == null ? "" : p.title;
        h.meta = p.meta == null ? "" : p.meta;
        h.button = p.pkg != null;
        h.dots = picks.size();
        h.dot = pickIndex;
        h.titleLayout = StaticLayout.Builder.obtain(h.title, 0, h.title.length(), titlePaint, Math.max(1, Math.round(HERO_TITLE_W * k)))
                .setMaxLines(2)
                .setEllipsize(TextUtils.TruncateAt.END)
                .setLineSpacing(0, 0.94f)
                .setIncludePad(false)
                .build();
        return h;
    }

    /** ←/→ on the hero: the next (or previous) of this hour's picks. */
    private boolean browse(int dir) {
        if (picks.size() < 2) return false;
        int next = pickIndex;
        for (int i = 0; i < picks.size(); i++) {
            next = (next + dir + picks.size()) % picks.size();
            if (zone != Z_HERO || picks.get(next).pkg != null) break;
        }
        if (next == pickIndex) return false;
        pickIndex = next;
        heroSlide = dir;
        refreshHero(true);
        Backdrop b = recs.backdrop(currentPick());
        if (b != null) showBackdrop(b);
        spoken.focusMoved();
        return true;
    }

    /** Swaps the background with a cross-fade (from one image to another, from the gradient to an image, or back). */
    private void showBackdrop(Backdrop b) {
        if (b == bgTo) return;
        long up = SystemClock.uptimeMillis();
        // In the middle of another swap, start from whichever is more visible.
        if (bgFadeAt == 0 || fadeEase(bgFadeAt, up) >= 0.5f) bgFrom = bgTo;
        bgTo = b;
        bgFadeAt = up;
        nightPair = false;
        if (b == null || glassOf(b) == null) return;
        if (bgFrom == null || glassOf(bgFrom) == null) {
            scene.setFrost(frostOf(b));
            scene.setGlassImage(glassOf(b));
        } else {
            scene.setGlassImages(glassOf(bgFrom), glassOf(b));
        }
    }

    /** What the glass shows: the photo lightened (by day), darkened (at night) or blended in between. */
    private int[] glassOf(Backdrop b) {
        if (b.nightGlass == null || night <= 0.001f) return b.lightGlass;
        if (night >= 0.999f) return b.nightGlass;
        // During the transition, the blend (only for the current background; a photo fading in uses the nearer side).
        if (b != bgTo) return night < 0.5f ? b.lightGlass : b.nightGlass;
        for (int i = 0; i < glassNight.length; i++) glassNight[i] = mix(b.lightGlass[i], b.nightGlass[i], night);
        return glassNight;
    }

    /** No photo: the glass reads the background's own gray (not Scene's default aurora, which isn't on screen). */
    private void neutralGlass() {
        int color = blend(0xFFEBEBF0, 0xFF141416, night);
        java.util.Arrays.fill(neutralFrostPx, color);
        java.util.Arrays.fill(neutralGlassPx, color);
        scene.setFrost(neutralFrostPx);
        scene.setGlassImage(neutralGlassPx);
        nightPair = false;
    }

    /** What the frosted glass shows (drawer, toasts): the blurred photo, darkened at night. */
    private int[] frostOf(Backdrop b) {
        int[] day = b.light == null ? b.frost : b.light;
        if (b.nightFrost == null || night <= 0.001f) return day;
        if (night >= 0.999f) return b.nightFrost;
        if (b != bgTo) return night < 0.5f ? day : b.nightFrost;
        for (int i = 0; i < frostNight.length; i++) frostNight[i] = mix(day[i], b.nightFrost[i], night);
        return frostNight;
    }

    // MARK: - Night look

    /** ViktorKav stays graphite; glass follows local sunrise and sunset. */
    private void checkNight(boolean animate) {
        boolean want = skin.isNight(data.isNight(System.currentTimeMillis()));
        if (want == nightTarget) return;
        nightTarget = want;
        if (animate && running) {
            nightFrom = night;
            nightAt = SystemClock.uptimeMillis();
        } else {
            night = want ? 1 : 0;
            nightAt = 0;
            nightChanged();
        }
    }

    /** Advances the day ⇄ night transition; true while it runs. */
    private boolean tickNight(long up) {
        if (nightAt == 0) return false;
        float t = Ui.clamp((up - nightAt) / NIGHT_MS), to = nightTarget ? 1 : 0;
        night = nightFrom + (to - nightFrom) * t * t * (3 - 2 * t);
        if (t >= 1) {
            night = to;
            nightAt = 0;
        }
        nightChanged();
        return true;
    }

    /** Redraws for the current night value (the glass now reads the lightened, blended or darkened photo). */
    private void nightChanged() {
        skin.apply(theme, night);
        if (bgFadeAt == 0 && bgTo != null && bgTo.lightGlass != null) {
            scene.setFrost(frostOf(bgTo));
            if (nightAt != 0 && bgTo.nightGlass != null) {
                if (!nightPair) {
                    scene.setGlassImages(bgTo.lightGlass, bgTo.nightGlass);
                    nightPair = true;
                }
                scene.setGlassMix(night);
            } else {
                scene.setGlassImage(glassOf(bgTo));
                nightPair = false;
            }
        } else if (bgFadeAt == 0 && bgTo == null) {
            neutralGlass();
        }
        heroDirty = statusDirty = tilesDirty = drawerDirty = gridDirty = true;
        sheetLayer.invalidate();
        sky.invalidate();
        platter.invalidate();
    }

    /** How dark it is: 0 = day, 1 = night (in between during the transition). */
    private float dark() {
        return night;
    }

    /** The day color or the night color, depending on the night value (blended during the transition). */
    private int tone(int onLight, int onDark) {
        return blend(onLight, onDark, dark());
    }

    private float tone(float onLight, float onDark) {
        return onLight + (onDark - onLight) * dark();
    }

    /** Semantic text colors shared with the public site. */
    private void applyTone() {
        lTitle.setColor(theme.TEXT);
        lTab.setColor(theme.SECONDARY);
        lTabOn.setColor(theme.FOCUS);
        lCardTitle.setColor(theme.TEXT);
        lCardMeta.setColor(theme.SECONDARY);
        lQuote.setColor(theme.SECONDARY);
        lTip.setColor(theme.TEXT);
        staleQuote.setColor(theme.MUTED);
        brandLabel.setColor(theme.MUTED);
        sheetTitle.setColor(theme.TEXT);
        gridLabel.setColor(theme.SECONDARY);
        toastPaint.setColor(theme.TEXT);
    }

    private boolean tickBackgroundFade(long up) {
        if (bgFadeAt == 0) return false;
        float e = fadeEase(bgFadeAt, up);
        if (bgTo != null && bgFrom != null && glassOf(bgFrom) != null && glassOf(bgTo) != null) {
            int[] from = frostOf(bgFrom), to = frostOf(bgTo);
            for (int i = 0; i < frostMix.length; i++) frostMix[i] = mix(from[i], to[i], e);
            scene.setFrost(frostMix);
            scene.setGlassMix(e);
        }
        if (e >= 1) {
            bgFadeAt = 0;
            bgFrom = null;
            if (bgTo == null) {
                neutralGlass();
            } else {
                scene.setFrost(frostOf(bgTo));
                if (glassOf(bgTo) != null) scene.setGlassImage(glassOf(bgTo));
            }
        }
        return true;
    }

    private boolean tickHeroFade(long up) {
        if (heroFadeAt == 0) return false;
        if (fadeEase(heroFadeAt, up) >= 1) {
            heroFadeAt = 0;
            heroFrom = null;
        }
        return true;
    }

    private float fadeEase(long start, long up) {
        return fadeEase(start, up, FADE_MS);
    }

    private static float fadeEase(long start, long up, float duration) {
        float t = Ui.clamp((up - start) / duration);
        return t * t * (3 - 2 * t);
    }

    private static int mix(int a, int b, float f) {
        int r = Math.round(((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = Math.round(((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = Math.round((a & 255) * (1 - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // MARK: - Background

    private void drawSky(Canvas c) {
        drawLightSky(c);
    }

    /** Blends a color on top (the drawer's veil) as part of drawing the image, without another layer. */
    private static android.graphics.ColorFilter veil(float amount, int color) {
        if (amount <= 0.002f) return null;
        float keep = 1 - amount;
        return new android.graphics.ColorMatrixColorFilter(new float[] {
            keep, 0, 0, 0, ((color >> 16) & 255) * amount,
            0, keep, 0, 0, ((color >> 8) & 255) * amount,
            0, 0, keep, 0, (color & 255) * amount,
            0, 0, 0, 1, 0});
    }

    private void drawImage(Canvas c, Bitmap image, float alpha) {
        if (image == null || alpha <= 0.004f) return;
        imagePaint.setAlpha(Math.round(255 * Math.min(1, alpha)));
        c.drawBitmap(image, null, screen, imagePaint);
    }

    // MARK: - Hero

    private static void text(Canvas c, String s, float x, float y, Paint p, int color, float alpha) {
        if (s == null || s.isEmpty()) return;
        p.setColor(Ui.alpha(color, alpha));
        c.drawText(s, x, y, p);
    }

    // MARK: - Corner capsule: time and weather (when the hero shows a recommendation) and icon-only buttons

    /** Live TV, the inputs with a device on, All Apps and Settings. */
    private static List<HomeApps.Item> statusList(Context c) {
        List<HomeApps.Item> list = new ArrayList<>();
        list.addAll(HomeApps.shortcuts(c));
        list.add(HomeApps.settings());
        return list;
    }

    private void setStatusItems(List<HomeApps.Item> list) {
        boolean same = list.size() == statusItems.size();
        for (int i = 0; same && i < list.size(); i++) same = list.get(i).key.equals(statusItems.get(i).key);
        String focusedKey = statusIndex < statusItems.size() ? statusItems.get(statusIndex).key : null;
        statusItems = list;
        if (!same || statusFocus.length != list.size()) {
            statusFocus = new Spring[list.size()];
            statusRects = new RectF[list.size()];
            int index = Math.min(statusIndex, Math.max(0, list.size() - 1));
            for (int i = 0; i < statusFocus.length; i++) {
                statusFocus[i] = new Spring(0.26f, 0.85f, 0);
                statusRects[i] = new RectF();
                if (list.get(i).key.equals(focusedKey)) index = i;   // a device came on: keep focus on the same button
            }
            statusIndex = index;
            if (zone == Z_STATUS && list.isEmpty()) zone = shelfZone();
            aim(statusFocus, zone == Z_STATUS ? statusIndex : -1, true);   // only the capsule's springs
            statusDirty = true;
        }
        layoutStatus();
    }

    private boolean showInfo() {
        return hero != null && !hero.clock;
    }

    private void layoutStatus() {
        if (capsuleText == null) return;
        int n = statusItems.size();
        float b = BUTTON * k, gap = 4 * k, pad = 6 * k;
        float info = 0;
        if (showInfo()) {
            info = 26 * k + capsuleText.measureText(clockText);
            HomeData.Weather wx = data.weather;
            if (!Double.isNaN(wx.temp)) {
                info += 22 * k + Symbols.width(getContext(), Symbols.weather(wx.code, wx.isDay), 24 * k) + 8 * k
                        + capsuleText.measureText(HomeData.degrees(wx.temp));
            }
            info += 22 * k;
        }
        capsuleInfoW = info;
        float buttons = n * b + Math.max(0, n - 1) * gap;
        float right = CONTENT_R * k, top = CAPSULE_TOP * k;
        float left = right - pad - buttons - (info > 0 ? info + 12 * k : pad);
        capsuleRect.set(left, top, right, top + CAPSULE_H * k);
        float x = right - pad - buttons, cy = capsuleRect.centerY();
        for (int i = 0; i < n; i++) {
            statusRects[i].set(x, cy - b / 2, x + b, cy + b / 2);
            x += b + gap;
        }
        statusDirty = true;
    }

    // MARK: - Channel metrics and shelf

    private void setShelf(List<HomeApps.Item> list) {
        boolean same = list.size() == shelf.size();
        for (int i = 0; same && i < list.size(); i++) same = list.get(i).key.equals(shelf.get(i).key);
        shelf = list;
        if(shelf.isEmpty() && zone==Z_SHELF) zone=shelfZone();
        if (!same || tileFocus.length != list.size()) {
            tileFocus = new Spring[list.size()];
            tileRects = new RectF[list.size()];
            for (int i = 0; i < tileFocus.length; i++) {
                tileFocus[i] = new Spring(0.34f, 0.74f, 0);
                tileRects[i] = new RectF();
            }
            shelfIndex = Math.min(shelfIndex, Math.max(0, list.size() - 1));
            retarget(true);
            layoutShelf();
        }
        tilesDirty = true;
        platter.invalidate();
    }

    private void layoutShelf() {
        int n = shelf.size();
        float pad = SHELF_PAD * k, gap = TILE_GAP * k, th = L_TILE_H * k;
        float full = (CONTENT_R - MARGIN) * k;
        float tw = Math.min(TILE_MAX_W * k, (full - Math.max(0, n - 1) * gap) / Math.max(1, n));
        float width = n * tw + Math.max(0, n - 1) * gap, left = (w - width) / 2f;
        float top = L_PLATTER_TOP * k;
        platterRect.set(left - pad, top, left + width + pad, top + th + 2 * pad);
        float x = left, y = top + pad;
        for (int i = 0; i < n; i++) {
            tileRects[i].set(x, y, x + tw, y + th);
            x += tw + gap;
        }
        crispLogos.clear();
    }

    /** Matte channel shelf or a refractive glass dock. */
    private void drawPlatter(Canvas c) {
        if (!skin.glass) {
            if (shelf.isEmpty()) return;
            fill.setShader(null);
            fill.setColor(theme.FIELD);
            c.drawRoundRect(platterRect, skin.radius * k, skin.radius * k, fill);
            border.setColor(theme.LINE);
            c.drawLine(platterRect.left, platterRect.top, platterRect.right, platterRect.top, border);

            return;
        }
        if (shelf.isEmpty()) return;
        float radius = (TILE_RADIUS + SHELF_PAD) * k;
        tmp.set(platterRect);
        tmp.offset(0, 18 * k);
        shadow.setColor(tone(0x1F000000, 0x52000000));
        c.drawRoundRect(tmp, radius, radius, shadow);
        // White glass by day; smoked glass at night.
        scene.liquid(c, platterRect, radius, tone(0xFFFFFFFF, SMOKE), tone(0.18f, 0.08f), tone(0.03f, 0.08f),
                tone(30, 34) * k, tone(22, 28) * k, tone(0.65f, 0.95f), 1);
    }

    /** Cached text keeps formatting, date work and feed reads out of the drawing path. */
    private void updateMetrics() {
        ChannelFeed feed = data.channel();
        for (int i = 0; i < 4; i++) {
            metricLabels[i] = feed.metricLabel(i, Ui.en);
            metricValues[i] = feed.metricValue(i, false, Ui.en);
            metricShort[i] = (Ui.en ? METRIC_SHORT_EN[i] : METRIC_SHORT_PT[i]) + " " + feed.metricValue(i, true, Ui.en);
            if (cardDim != null && metricsCard.width() > 0) {
                float room = metricsCard.width() - 92 * k - metricValuePaint.measureText(metricValues[i]);
                metricLabels[i] = TextUtils.ellipsize(metricLabels[i], new TextPaint(cardDim), Math.max(1, room),
                        TextUtils.TruncateAt.END).toString();
            }
        }
        metricsSource = channelSourceText(feed);
        drawerSource = cardDim == null || metricsCard.width() <= 0 ? metricsSource
                : TextUtils.ellipsize(metricsSource, new TextPaint(cardDim), Math.max(1, metricsCard.width() - 68 * k),
                        TextUtils.TruncateAt.END).toString();
        if(recs.publicMode()) {
            DiscoverySource.Status state=recs.discoveryStatus();
            emptyTitle=state.loading ? Ui.tr("Buscando vídeos públicos", "Loading public videos")
                    : state.failed>0 ? Ui.tr("Fontes indisponíveis", "Sources unavailable")
                    : Ui.tr("Nenhum vídeo nesta aba", "No videos in this tab");
            emptyDetail=recs.discoveryMessage();
        } else if (Config.CHANNEL_FEED_URL.trim().isEmpty()) {
            emptyTitle = Ui.tr("Feed opcional não configurado", "Optional feed is not configured");
            emptyDetail = Ui.tr("Apps e skins já funcionam. Configure seu servidor para ver as inscrições.",
                    "Apps and skins are ready. Configure your server to see subscriptions.");
        } else if ("authorization_required".equals(feed.recommendationsStatus)) {
            emptyTitle = Ui.tr("Conecte suas inscrições", "Connect your subscriptions");
            emptyDetail = Ui.tr("Autorize o acesso às suas inscrições do YouTube.",
                    "Authorize access to your YouTube subscriptions.");
        } else if ("loading".equals(feed.recommendationsStatus)) {
            emptyTitle = Ui.tr("Buscando vídeos das inscrições", "Loading subscription videos");
            emptyDetail = Ui.tr("Os vídeos aparecerão automaticamente.", "Videos will appear automatically.");
        } else if ("ready".equals(feed.recommendationsStatus)) {
            emptyTitle = Ui.tr("Nenhum vídeo nesta aba", "No videos in this tab");
            emptyDetail = recommendationSourceText(feed);
        } else {
            emptyTitle = Ui.tr("Inscrições indisponíveis", "Subscriptions unavailable");
            emptyDetail = feed.recommendationsUpdatedAt > 0 ? recommendationSourceText(feed)
                    : Ui.tr("Tentaremos novamente automaticamente.", "We will retry automatically.");
        }
        heroDirty = drawerDirty = true;
    }

    private static String recommendationSourceText(ChannelFeed feed) {
        if (feed.recommendationsUpdatedAt <= 0) return Ui.tr("Suas inscrições do YouTube", "Your YouTube subscriptions");
        String date = new java.text.SimpleDateFormat(Ui.en ? "MMM d, HH:mm" : "dd/MM HH:mm",
                Ui.en ? java.util.Locale.US : new java.util.Locale("pt", "BR"))
                .format(new java.util.Date(feed.recommendationsUpdatedAt));
        return Ui.tr("Inscrições · ", "Subscriptions · ")
                + (feed.recommendationsStale ? Ui.tr("desatualizado · ", "outdated · ") : "") + date;
    }

    static String channelSourceText(ChannelFeed feed) {
        if (feed.updatedAt <= 0) return Ui.tr("YouTube · sem dados", "YouTube · no data");
        String date = new java.text.SimpleDateFormat(Ui.en ? "MMM d, HH:mm" : "dd/MM HH:mm",
                Ui.en ? java.util.Locale.US : new java.util.Locale("pt", "BR"))
                .format(new java.util.Date(feed.updatedAt));
        String age = HomeData.staleness(feed.updatedAt, 30_000L);
        return "YouTube · " + (feed.stale ? Ui.tr("desatualizado · ", "outdated · ") : "")
                + date + (age.isEmpty() ? "" : " · " + age);
    }

    /** Every compact count carries its own label; the source is dated even when fresh. */
    private void drawMetrics(Canvas c) {
        float right = CONTENT_R * k;
        applyTone();
        float fade = 1;
        for (int i = 3; i < 6; i++) fade = Math.min(fade, 1 - Ui.clamp(topFocus[i].value));
        if (fade <= 0.01f) return;
        int color = lQuote.getColor();
        lQuote.setColor(Ui.alpha(color, fade));
        float base = (L_TABBAR_TOP + L_TABBAR_H / 2) * k + Ui.halfCap(lQuote);
        float total = 72 * k;
        for (String value : metricShort) if (value != null) total += lQuote.measureText(value);
        float x = right - total;
        for (String value : metricShort) {
            if (value == null) continue;
            c.drawText(value, x, base, lQuote);
            x += lQuote.measureText(value) + 24 * k;
        }
        lQuote.setColor(color);
        staleQuote.setColor(Ui.alpha(theme.MUTED, fade));
        c.drawText(metricsSource, right, base + 37 * k, staleQuote);
    }

    private void drawTiles(Canvas c) {
        // The focused one last: it grows over its neighbors without being covered by them.
        int top = -1;
        float most = 0.02f;
        for (int i = 0; i < shelf.size(); i++) {
            if (tileFocus[i].value > most) {
                most = tileFocus[i].value;
                top = i;
            }
        }
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < shelf.size(); i++) {
                if ((pass == 0) == (i == top)) continue;
                drawShelfTile(c, i);
            }
        }
    }

    /**
     * App icon like the ones in the tvOS 27 Dock: the brand color edge to edge (a soft gradient) with the logo.
     * Focused: a restrained lift and an explicit cyan outline, shared with cards and navigation.
     */
    private void drawShelfTile(Canvas c, int i) {
        HomeApps.Item it = shelf.get(i);
        float f = tileFocus[i].value, fc = Ui.clamp(f), s = 1 + FOCUS_GROW * f;
        RectF base = tileRects[i];
        float bw = base.width(), bh = base.height(), r0 = TILE_RADIUS * k;
        float cx = base.centerX(), cy = base.centerY() - (skin==Skin.GTA_VI ? 14*k*f : 0);
        cell.set(cx - bw * s / 2, cy - bh * s / 2, cx + bw * s / 2, cy + bh * s / 2);
        float r = r0 * s;
        // Shadow at the resting icon size, enlarged by the transform (so the blur stays cached): short at rest, deep
        // and lower when focused.
        c.save();
        c.translate(cx, cy);
        c.scale(s, s);
        tmp.set(-bw / 2, -bh / 2, bw / 2, bh / 2);
        tmp.offset(0, (4 + 14 * f) * k);
        shadowDeep.setColor(Ui.alpha(0xFF000000, tone(0.14f, 0.3f) + tone(0.18f, 0.3f) * fc));
        c.drawRoundRect(tmp, r0, r0, shadowDeep);
        c.restore();
        int[] style = TILE_STYLE.get(it.key);
        if (it.logo != null && style != null) {
            tileFill.setShader(new LinearGradient(0, cell.top, 0, cell.bottom, style[0], style[1], Shader.TileMode.CLAMP));
            c.drawRoundRect(cell, r, r, tileFill);
            tileFill.setShader(null);
            if (fc > 0.01f) {
                tileFill.setShader(new LinearGradient(0, cell.top, 0, cell.top + cell.height() * 0.5f,
                        Ui.alpha(0xFFFFFFFF, 0.08f * fc), 0x00FFFFFF, Shader.TileMode.CLAMP));
                c.drawRoundRect(cell, r, r, tileFill);
                tileFill.setShader(null);
            }
            drawLogo(c, it, cell, s, style[2]);
        } else if (it.logo != null) {
            tileFill.setShader(null);
            tileFill.setColor(0xFF161618);
            c.drawRoundRect(cell, r, r, tileFill);
            drawLogo(c, it, cell, s, 0);
        } else {
            clip.reset();
            clip.addRoundRect(cell, r, r, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            if (it.tile != null) c.drawBitmap(it.tile, null, cell, bitmapPaint);
            c.restore();
        }
        if (fc > 0.01f) {
            if(skin==Skin.GTA_VI) drawNeon(c,cell,r,fc);
            else {
                rim.setShader(null);
                rim.setColor(Ui.alpha(theme.FOCUS, fc));
                c.drawRoundRect(cell, r, r, rim);
            }
        }
    }

    /** Cached gradient and three narrow strokes: stationary neon, no blur or frame allocations. */
    private void drawNeon(Canvas c,RectF box,float radius,float focus) {
        neonMatrix.setScale(box.width(),box.height());
        neonMatrix.postTranslate(box.left,box.top);
        neonGradient.setLocalMatrix(neonMatrix);
        neonRim.setShader(neonGradient);
        neonRim.setStrokeWidth(11*k);neonRim.setAlpha(Math.round(35*focus));c.drawRoundRect(box,radius,radius,neonRim);
        neonRim.setStrokeWidth(7*k);neonRim.setAlpha(Math.round(75*focus));c.drawRoundRect(box,radius,radius,neonRim);
        neonRim.setStrokeWidth(3*k);neonRim.setAlpha(Math.round(255*focus));c.drawRoundRect(box,radius,radius,neonRim);
    }

    /**
     * Logo at its "optical" size (all with the same amount of ink, plus each one's own adjustment, never past 80% × 62%
     * of the tile), centered and already filtered down to the focused tile size: when focused it is drawn pixel for
     * pixel, without resampling.
     */
    private void drawLogo(Canvas c, HomeApps.Item it, RectF box, float s, int mode) {
        Bitmap logo = crispLogo(it, mode == 2 && it.logoDark != null);
        if (logo == null) return;
        float scale = s / (1 + FOCUS_GROW);
        float dw = logo.getWidth() * scale, dh = logo.getHeight() * scale;
        float left = box.centerX() - dw / 2, top = box.centerY() - dh / 2;
        if (scale > 0.998f) {
            left = Math.round(left);
            top = Math.round(top);
        }
        tmp.set(left, top, left + dw, top + dh);
        bitmapPaint.setColorFilter(mode == 1 ? whiteLogo : null);
        c.drawBitmap(logo, null, tmp, bitmapPaint);
        bitmapPaint.setColorFilter(null);
    }

    private Bitmap crispLogo(HomeApps.Item it, boolean dark) {
        Bitmap src = dark ? it.logoDark : it.logo;
        if (tileRects.length == 0) return src;
        String key = it.key + "@" + System.identityHashCode(src) + "@" + Math.round(tileRects[0].width());
        Bitmap cached = crispLogos.get(key);
        if (cached != null) return cached;
        float bw = tileRects[0].width() * (1 + FOCUS_GROW), bh = tileRects[0].height() * (1 + FOCUS_GROW);
        float lw = src.getWidth(), lh = src.getHeight();
        float scale = (float) Math.sqrt(bw * bh * 0.085f / (lw * lh * Math.max(0.08f, it.logoInk))) * it.logoScale;
        scale = Math.min(scale, Math.min(bw * 0.76f / lw, bh * 0.58f / lh));
        Bitmap out = downscale(src, Math.round(lw * scale), Math.round(lh * scale));
        crispLogos.put(key, out);
        return out;
    }

    /** Halves the size while it can (a 2×2 average, no aliasing), then finishes at the exact size. */
    private static Bitmap downscale(Bitmap src, int w, int h) {
        w = Math.max(1, w);
        h = Math.max(1, h);
        Bitmap b = src;
        while (b.getWidth() / 2 >= w && b.getHeight() / 2 >= h) {
            Bitmap half = Bitmap.createScaledBitmap(b, b.getWidth() / 2, b.getHeight() / 2, true);
            if (b != src) b.recycle();
            b = half;
        }
        Bitmap out = Bitmap.createScaledBitmap(b, w, h, true);
        if (b != src && b != out) b.recycle();
        return out;
    }

    // MARK: - Bottom drawer

    private static List<HomeApps.Item> drawerList(Context c) {
        List<HomeApps.Item> list = HomeApps.allInputs(c);
        list.addAll(HomeApps.drawerShortcuts());
        return list;
    }

    private void setDrawerItems(List<HomeApps.Item> list) {
        int inputs = 0;
        while (inputs < list.size() && (list.get(inputs).kind == HomeApps.INPUT || list.get(inputs).kind == HomeApps.LIVE_TV)) inputs++;
        boolean same = list.size() == drawerItems.size();
        for (int i = 0; same && i < list.size(); i++) {
            same = list.get(i).key.equals(drawerItems.get(i).key) && list.get(i).connected == drawerItems.get(i).connected;
        }
        drawerItems = list;
        drawerInputs = inputs;
        if (drawerFocus.length != list.size()) {
            drawerFocus = new Spring[list.size()];
            drawerRects = new RectF[list.size()];
            for (int i = 0; i < drawerFocus.length; i++) {
                drawerFocus[i] = new Spring(0.28f, 0.85f, 0);
                drawerRects[i] = new RectF();
            }
            drawerIndex = Math.min(drawerIndex, Math.max(0, list.size() - 1));
            retarget(true);
        }
        layoutDrawer();
        if (!same) drawerDirty = true;
    }

    private void layoutDrawer() {
        int n = drawerItems.size();
        float left = MARGIN * k, right = CONTENT_R * k;
        float gap = 18 * k, groupGap = 56 * k;
        int groups = drawerInputs > 0 && drawerInputs < n ? 2 : 1;
        float tw = Math.min(230 * k, (right - left - Math.max(0, n - groups) * gap - (groups - 1) * groupGap) / Math.max(1, n));
        float x = left, top = ROW_TOP * k;
        for (int i = 0; i < n; i++) {
            if (i == drawerInputs && i > 0) x += groupGap - gap;
            drawerRects[i].set(x, top, x + tw, top + ROW_H * k);
            x += tw + gap;
        }
        float cardsTop = CARDS_TOP * k;
        if (Config.SHOW_CHANNEL_METRICS) {
            float split = left + (right - left) * 0.585f;
            weatherCard.set(left, cardsTop, split - 16 * k, cardsTop + CARDS_H * k);
            metricsCard.set(split + 16 * k, cardsTop, right, cardsTop + CARDS_H * k);
        } else {
            weatherCard.set(left, cardsTop, right, cardsTop + CARDS_H * k);
            metricsCard.setEmpty();
        }
        drawerDirty = true;
    }

    private void openDrawer() {
        if (drawerItems.isEmpty()) return;
        drawerOpen = true;
        drawer.target = 1;
        zone = Z_DRAWER;
        drawerIndex = shelf.isEmpty() ? 0 : nearest(drawerRects, tileRects[shelfIndex].centerX());
        for (int i = 0; i < drawerFocus.length; i++) drawerFocus[i].snap(i == drawerIndex ? 1 : 0);
        drawerDirty = true;
    }

    private void closeDrawer() {
        drawerOpen = false;
        drawer.target = 0;
        zone = shelfZone();
        for (Spring f : drawerFocus) f.snap(0);   // the drawer goes away: its focus doesn't need to animate
        if (!shelf.isEmpty() && drawerIndex < drawerRects.length) shelfIndex = nearest(tileRects, drawerRects[drawerIndex].centerX());
    }

    /** Color for the drawer's text and symbols: dark by day, white at night. */
    private int drawerInk(float alpha) {
        return Ui.alpha(tone(L_INK, 0xFFFFFFFF), alpha);
    }

    /** Skin material for drawer cards and shortcuts. */
    private void drawerGlass(Canvas c, RectF r, float radius, float lightTint, int shadowColor, float drop) {
        if (!skin.glass) {
            fill.setShader(null);
            fill.setColor(theme.SURFACE);
            c.drawRoundRect(r, skin.radius * k, skin.radius * k, fill);

            return;
        }
        float dk = dark();
        if (dk < 0.999f) {
            tmp.set(r);
            tmp.offset(0, drop);
            shadow.setColor(Ui.alpha(shadowColor, 1 - dk));
            c.drawRoundRect(tmp, radius, radius, shadow);
            scene.glass(c, r, radius, 0xFFFFFFFF, lightTint, 0, 0, 0.02f, 1, 1 - dk);
        }
        if (dk > 0.001f) scene.glass(c, r, radius, SMOKE, 0.18f, 0, 0, 0.02f, 1, dk);
    }

    private void drawerCard(Canvas c, RectF r) {
        drawerGlass(c, r, 30 * k, 0.28f, 0x1A000000, 10 * k);
    }

    private void drawDrawer(Canvas c) {
        if (drawerItems.isEmpty()) return;
        rowTitle.setColor(theme.ACCENT);
        cardTitle.setColor(theme.SECONDARY);
        cardText.setColor(drawerInk(0.95f));
        cardDim.setColor(theme.SECONDARY);
        cardDimRight.setColor(theme.MUTED);
        bigTemp.setColor(drawerInk(1));
        hourPaint.setColor(theme.SECONDARY);
        hourTemp.setColor(drawerInk(0.95f));
        metricValuePaint.setColor(drawerInk(0.95f));
        float titleBase = ROW_TITLE * k;
        if (drawerInputs > 0) c.drawText(Ui.tr("Entradas", "Inputs"), drawerRects[0].left + 4 * k, titleBase, rowTitle);
        if (drawerInputs < drawerItems.size()) c.drawText(Ui.tr("Atalhos", "Shortcuts"), drawerRects[drawerInputs].left + 4 * k, titleBase, rowTitle);
        int top = -1;
        for (int i = 0; i < drawerItems.size(); i++) if (drawerFocus[i].value > 0.02f && (top < 0 || drawerFocus[i].value > drawerFocus[top].value)) top = i;
        for (int i = 0; i < drawerItems.size(); i++) if (i != top) drawDrawerTile(c, i);
        if (top >= 0) drawDrawerTile(c, top);
        drawWeatherCard(c, weatherCard);
        if (Config.SHOW_CHANNEL_METRICS) drawMetricsCard(c, metricsCard);
    }

    /** Drawer button: disconnected inputs are muted; focus adds a cyan outline and foreground. */
    private void drawDrawerTile(Canvas c, int i) {
        HomeApps.Item it = drawerItems.get(i);
        float f = Ui.clamp(drawerFocus[i].value), s = 1 + 0.07f * f;
        RectF base = drawerRects[i];
        float cx = base.centerX(), cy = base.centerY() - (skin==Skin.GTA_VI ? 14*k*f : 0);
        cell.set(cx - base.width() * s / 2, cy - base.height() * s / 2, cx + base.width() * s / 2, cy + base.height() * s / 2);
        float r = (skin.glass ? 24 : skin.radius) * k * s;
        if (f > 0.01f) {
            tmp.set(cell);
            tmp.offset(0, 12 * k * f);
            shadow.setColor(Ui.alpha(0xFF000000, 0.45f * f));
            c.drawRoundRect(tmp, r, r, shadow);
        }
        if (f < 0.99f) drawerGlass(c, cell, r, 0.24f, 0x14000000, 6 * k);
        if (f > 0.01f) {
            fill.setShader(null);
            fill.setColor(Ui.alpha(theme.FOCUS_FIELD, f));
            c.drawRoundRect(cell, r, r, fill);
        }
        boolean off = it.kind == HomeApps.INPUT && !it.connected;
        if (f > 0.01f) {
            rim.setColor(Ui.alpha(theme.FOCUS, f));
            c.drawRoundRect(cell, r, r, rim);
        }
        int ink = blend(off ? theme.MUTED : theme.TEXT, skin.glass ? theme.ON_FOCUS : theme.FOCUS, f);
        Symbols.draw(getContext(), c, it.symbol, cx, cell.top + cell.height() * 0.4f, 34 * k * s, ink);
        drawerLabel.setColor(ink);
        drawerLabel.setTextSize(23 * k * s);
        float room = cell.width() - 16 * k, wide = drawerLabel.measureText(it.label);
        // A long name ("Home Settings", an input you renamed) shrinks a little before it gets cut.
        if (wide > room) drawerLabel.setTextSize(Math.max(18 * k * s, 23 * k * s * room / wide));
        String label = TextUtils.ellipsize(it.label, new TextPaint(drawerLabel), room, TextUtils.TruncateAt.END).toString();
        c.drawText(label, cx, cell.top + cell.height() * 0.8f, drawerLabel);
        drawerLabel.setTextSize(23 * k);
    }

    /** Weather for your location: now (large), the next 6 hours, and sunrise and sunset. */
    private void drawWeatherCard(Canvas c, RectF r) {
        drawerCard(c, r);
        float x = r.left + 34 * k;
        c.drawText(Config.CITY.trim().isEmpty() ? Ui.tr("Clima", "Weather") : Config.CITY.trim(), x, r.top + 54 * k, cardTitle);
        HomeData.Weather wx = data.weather;
        if (Double.isNaN(wx.temp)) {
            c.drawText(Ui.tr("Sem dados do clima agora.", "No weather data right now."), x, r.top + 120 * k, cardDim);
            return;
        }
        String symbol = Symbols.weather(wx.code, wx.isDay);
        float sw = Symbols.width(getContext(), symbol, 52 * k);
        Symbols.draw(getContext(), c, symbol, x + sw / 2, r.top + 132 * k, 52 * k, drawerInk(0.95f));
        String now = HomeData.degrees(wx.temp);
        c.drawText(now, x + sw + 18 * k - Ui.leftBearing(bigTemp, now), r.top + 170 * k, bigTemp);
        c.drawText(HomeData.condition(wx.code, wx.isDay), x, r.top + 220 * k, cardText);
        c.drawText(Ui.en ? "H:" + HomeData.degrees(wx.max) + "   L:" + HomeData.degrees(wx.min)
                : "Máx. " + HomeData.degrees(wx.max) + "   Mín. " + HomeData.degrees(wx.min), x, r.top + 258 * k, cardDim);
        float split = r.left + 392 * k;
        fill.setShader(null);
        fill.setColor(tone(0x1A000000, 0x24FFFFFF));
        c.drawRoundRect(split - k, r.top + 34 * k, split + k, r.bottom - 34 * k, k, k, fill);
        float hx = split + 30 * k, hw = (r.right - 30 * k - hx) / 6;
        for (int i = 0; i < wx.hours.size() && i < 6; i++) {
            float hc = hx + hw * (i + 0.5f);
            c.drawText(HomeData.hour(wx.hours.get(i)), hc, r.top + 96 * k, hourPaint);
            Symbols.draw(getContext(), c, Symbols.weather(wx.hourCode.get(i), wx.hourDay.get(i)), hc, r.top + 142 * k, 30 * k, drawerInk(0.9f));
            c.drawText(HomeData.degrees(wx.hourTemp.get(i)), hc, r.top + 196 * k, hourTemp);
        }
        float sx = hx, base = r.top + 258 * k;
        if (wx.sunrise != 0) sx = sunItem(c, "sunrise", Ui.tr("Nascer ", "Sunrise ") + Ui.time(wx.sunrise), sx, base) + 36 * k;
        if (wx.sunset != 0) sunItem(c, "sunset", Ui.tr("Pôr do sol ", "Sunset ") + Ui.time(wx.sunset), sx, base);
    }

    private float sunItem(Canvas c, String symbol, String label, float x, float base) {
        float size = 22 * k, sw = Symbols.width(getContext(), symbol, size);
        Symbols.draw(getContext(), c, symbol, x + sw / 2, base - Ui.halfCap(cardDim), size, tone(L_DIM, 0xB3FFFFFF));
        c.drawText(label, x + sw + 10 * k, base, cardDim);
        return x + sw + 10 * k + cardDim.measureText(label);
    }

    /** Public lifetime channel counts and counts on the latest video. */
    private void drawMetricsCard(Canvas c, RectF r) {
        drawerCard(c, r);
        float x = r.left + 34 * k, right = r.right - 34 * k;
        c.drawText("ViktorKav · @vkav", x, r.top + 49 * k, cardTitle);
        for (int i = 0; i < 4; i++) {
            float base = r.top + (98 + 42 * i) * k;
            c.drawText(metricLabels[i], x, base, cardDim);
            c.drawText(metricValues[i], right, base, metricValuePaint);
        }
        c.drawText(drawerSource, x, r.bottom - 22 * k, cardDim);
    }

    // MARK: - Focus

    /** Sets the springs' targets from the current focus (snap: no animation). */
    private void retarget(boolean snap) {
        if(xboxPanel!=null)xboxPanel.panelFocus(!sheetOpen&&zone==Z_XBOX);
        // Only the group whose focus changed is redrawn (moving along the shelf doesn't redraw the hero or capsule).
        boolean tilesChanged = aim(tileFocus, !sheetOpen && zone == Z_SHELF ? shelfIndex : -1, snap);
        boolean statusChanged = aim(statusFocus, !sheetOpen && zone == Z_STATUS ? statusIndex : -1, snap);
        boolean drawerChanged = aim(drawerFocus, !sheetOpen && zone == Z_DRAWER ? drawerIndex : -1, snap);
        boolean heroChanged = heroFocus.target != (!sheetOpen && zone == Z_HERO ? 1 : 0);
        heroFocus.target = !sheetOpen && zone == Z_HERO ? 1 : 0;
        if (snap) heroFocus.snap(heroFocus.target);
        updateCardRange();
        boolean topChanged = aim(topFocus, !sheetOpen && zone == Z_TOP ? topIndex : -1, snap);
        heroChanged |= aim(cardFocus, !sheetOpen && zone == Z_CARDS ? cardIndex : -1, snap) | topChanged;
        statusChanged |= topChanged;
        tilesDirty |= snap || tilesChanged;
        statusDirty |= snap || statusChanged;
        heroDirty |= snap || heroChanged;
        drawerDirty |= snap || drawerChanged;
        spoken.focusMoved();
    }

    /** Aims a group's springs (only `focused` at 1); returns true if any target changed. */
    private static boolean aim(Spring[] springs, int focused, boolean snap) {
        boolean changed = false;
        for (int i = 0; i < springs.length; i++) {
            float target = i == focused ? 1 : 0;
            changed |= springs[i].target != target;
            springs[i].target = target;
            if (snap) springs[i].snap(target);
        }
        return changed;
    }

    // MARK: - "All Apps" sheet

    private void setOthers(List<HomeApps.Item> list) {
        others = list;
        gridFocus = new Spring[list.size()];
        for (int i = 0; i < gridFocus.length; i++) gridFocus[i] = new Spring(0.3f, 0.82f, 0);
        gridLabels = null;
        gridIndex = Math.min(gridIndex, Math.max(0, list.size() - 1));
        retargetGrid(true);
        gridDirty = true;
    }

    private void openSheet() {
        sheetOpen = true;
        if(skin==Skin.GTA_VI)stopGameWallpaper();
        gridIndex = 0;
        scroll.snap(0);
        retargetGrid(true);
        retarget(false);
        sheet.target = 1;
        gridDirty = true;
    }

    private void closeSheet() {
        sheetOpen = false;
        startGameWallpaper();
        sheet.target = 0;
        retarget(false);
    }

    private void retargetGrid(boolean snap) {
        for (int i = 0; i < gridFocus.length; i++) {
            gridFocus[i].target = sheetOpen && i == gridIndex ? 1 : 0;
            if (snap) gridFocus[i].snap(gridFocus[i].target);
        }
        int rows = Math.max(1, (others.size() + COLUMNS - 1) / COLUMNS);
        int visible = Math.min(rows, VISIBLE_ROWS);
        int r = gridIndex / COLUMNS;
        float target = scroll.target;
        if (r < target) target = r;
        else if (r > target + visible - 1) target = r - visible + 1;
        scroll.target = Math.max(0, Math.min(rows - visible, target));
        if (snap) scroll.snap(scroll.target);
        spoken.focusMoved();
    }

    private void drawSheet(Canvas c) {
        applyTone();
        if (skin.glass) drawLightSky(c); else c.drawColor(theme.BACKGROUND);
        float shift = scroll.value * GRID_ROW * k;
        c.drawText(Ui.tr("Todos os Apps", "All Apps"), w / 2f, 124 * k - shift, sheetTitle);
        int n = others.size();
        if (gridLabels == null || gridLabels.length != n) {
            gridLabels = new String[n];
            for (int i = 0; i < n; i++) {
                gridLabels[i] = TextUtils.ellipsize(others.get(i).label, gridLabel, (GRID_W - 10) * k, TextUtils.TruncateAt.END).toString();
            }
        }
        float gridWidth = COLUMNS * GRID_W + (COLUMNS - 1) * GRID_GAP;
        float left = (1920 - gridWidth) / 2 * k;
        float gridTop = GRID_TOP * k;
        for (int i = 0; i < n; i++) {
            int r = i / COLUMNS, col = i % COLUMNS;
            float y = gridTop + r * GRID_ROW * k - shift;
            if (y > h || y + GRID_ROW * k < 0) continue;
            float x = left + col * (GRID_W + GRID_GAP) * k;
            RectF base = new RectF(x, y, x + GRID_W * k, y + GRID_H * k);
            float f = gridFocus[i].value;
            drawCard(c, others.get(i).tile, base, GRID_RADIUS * k, f, 0.08f);
            if (sheetOpen && i == gridIndex) focusedCell.set(cell);
            gridLabel.setColor(theme.appLabel(f));
            c.drawText(gridLabels[i], base.centerX(), base.bottom + (40 + 6 * f) * k, gridLabel);
        }
    }

    /** 16:9 sheet card. Focused (the shelf's subtle focus): it grows, with a shadow, a soft sheen and a thin border. */
    private void drawCard(Canvas c, Bitmap image, RectF base, float radius, float f, float grow) {
        float s = 1 + grow * f;
        float cx = base.centerX(), cy = base.centerY() - (skin==Skin.GTA_VI ? 14*k*f : 0);
        cell.set(cx - base.width() * s / 2, cy - base.height() * s / 2, cx + base.width() * s / 2, cy + base.height() * s / 2);
        float r = radius * s;
        float fc = Ui.clamp(f);
        if (f > 0.01f) {
            tmp.set(cell);
            tmp.offset(0, 16 * k * f);
            shadow.setColor(Ui.alpha(0xFF000000, 0.55f * fc));
            c.drawRoundRect(tmp, r, r, shadow);
        }
        clip.reset();
        clip.addRoundRect(cell, r, r, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        if (image != null) c.drawBitmap(image, null, cell, bitmapPaint);
        if (f > 0.01f) {
            sheen.setShader(new LinearGradient(0, cell.top, 0, cell.top + cell.height() * 0.5f,
                    Ui.alpha(0xFFFFFFFF, 0.1f * fc), 0x00FFFFFF, Shader.TileMode.CLAMP));
            c.drawRect(cell, sheen);
        }
        if (fc < 0.99f) {
            veil.setColor(Ui.alpha(0xFF000000, 0.08f * (1 - fc)));
            c.drawRect(cell, veil);
        }
        c.restore();
        border.setColor(0x14FFFFFF);
        c.drawRoundRect(cell, r, r, border);
        if (f > 0.01f) {
            if(skin==Skin.GTA_VI) drawNeon(c,cell,r,fc);
            else {
                rim.setShader(null);
                rim.setColor(Ui.alpha(theme.FOCUS, fc));
                rim.setStrokeWidth(1.5f * k);
                c.drawRoundRect(cell, r, r, rim);
                rim.setStrokeWidth(3 * k);
            }
        }
    }

    // MARK: - Toasts

    void showToast(String text) {
        toasts.add(text);
        announceForAccessibility(text);
    }

    /** Advances the toast queue; returns true while a toast fades in or out (animation). */
    private boolean tickToast(long up) {
        if (toast != null && up - toastAt > TOAST_MS) {
            toast = null;
            toastLayer.invalidate();
        }
        if (toast == null && toastPaint != null) {
            String next = toasts.poll();
            if (next != null) {
                toast = layout(next);
                toastAt = up;
            }
        }
        if (toast == null) return false;
        long age = up - toastAt;
        boolean fading = age < 350 || age > TOAST_MS - 450;
        if (fading) toastLayer.invalidate();
        return fading;
    }

    private void drawToast(Canvas c) {
        if (!skin.glass) {
            if (toast == null) return;
            float age = (SystemClock.uptimeMillis() - toastAt) / 1000f;
            float a = Math.min(Ui.clamp(age / 0.3f), Ui.clamp((TOAST_MS / 1000f - age) / 0.4f));
            if (a <= 0) return;
            float padX = 28 * k, padY = 18 * k, icon = 26 * k, iconW = Symbols.width(getContext(), "bell", icon);
            float tw = toast.getWidth() + iconW + 16 * k, th = toast.getHeight();
            float toastTop = 64 * k - (1 - a) * 16 * k;
            tmp.set((w - tw) / 2f - padX, toastTop, (w + tw) / 2f + padX, toastTop + th + 2 * padY);
            int save = c.saveLayerAlpha(tmp.left - 4, tmp.top - 4, tmp.right + 4, tmp.bottom + 4, Math.round(255 * a));
            fill.setShader(null);
            fill.setColor(theme.FIELD);
            c.drawRoundRect(tmp, skin.radius * k, skin.radius * k, fill);
            Symbols.draw(getContext(), c, "bell", tmp.left + padX + iconW / 2, tmp.centerY(), icon, theme.FOCUS);
            c.translate(tmp.left + padX + iconW + 16 * k, tmp.top + padY);
            toast.draw(c);
            c.restoreToCount(save);

            return;
        }
        if (toast == null) return;
        float age = (SystemClock.uptimeMillis() - toastAt) / 1000f;
        float a = Math.min(Ui.clamp(age / 0.3f), Ui.clamp((TOAST_MS / 1000f - age) / 0.4f));
        if (a <= 0) return;
        float padX = 28 * k, padY = 18 * k, icon = 26 * k, iconW = Symbols.width(getContext(), "bell", icon);
        float tw = toast.getWidth() + iconW + 16 * k, th = toast.getHeight();
        float toastTop = 64 * k - (1 - a) * 16 * k;
        tmp.set((w - tw) / 2f - padX, toastTop, (w + tw) / 2f + padX, toastTop + th + 2 * padY);
        int save = c.saveLayerAlpha(tmp.left - 4, tmp.top - 4, tmp.right + 4, tmp.bottom + 4, Math.round(255 * a));
        scene.liquid(c, tmp, Math.min(tmp.height() / 2, 32 * k), theme.SURFACE, .92f, .02f,
                16 * k, 10 * k, .7f, 1);
        Symbols.draw(getContext(), c, "bell", tmp.left + padX + iconW / 2, tmp.centerY(), icon, theme.TEXT);
        c.translate(tmp.left + padX + iconW + 16 * k, tmp.top + padY);
        toast.draw(c);
        c.restoreToCount(save);
    }

    private StaticLayout layout(String text) {
        int max = Math.round(720 * k);
        int width = (int) Math.min(max, Math.ceil(Layout.getDesiredWidth(text, toastPaint)));
        return StaticLayout.Builder.obtain(text, 0, text.length(), toastPaint, Math.max(1, width))
                .setMaxLines(2)
                .setEllipsize(TextUtils.TruncateAt.END)
                .build();
    }

    /** New notices from the main process (mode switches, the check after the TV boots): those from the last 24 h. */
    private void checkNotices() {
        final Context c = getContext().getApplicationContext();
        LOADER.execute(() -> {
            JSONArray list = HomeMode.state(c).optJSONArray("notices");
            if (list == null) return;
            long seen = ui.getLong("seenNotice", 0), newest = seen;
            long cutoff = System.currentTimeMillis() - 24 * 3600_000L;
            final List<String> fresh = new ArrayList<>();
            for (int i = list.length() - 1; i >= 0; i--) {   // the list comes newest first
                JSONObject o = list.optJSONObject(i);
                if (o == null) continue;
                long at = o.optLong("at");
                if (at <= seen || at < cutoff) continue;
                fresh.add(o.optString("text"));
                newest = Math.max(newest, at);
            }
            if (newest > seen) ui.edit().putLong("seenNotice", newest).apply();
            if (!fresh.isEmpty()) handler.post(() -> { for (String t : fresh) showToast(t); });
        });
    }

    // MARK: - Lists (in the background, so returning to the home screen isn't delayed)

    private void reload() {
        final Context c = getContext().getApplicationContext();
        LOADER.execute(() -> {
            final List<HomeApps.Item> s = HomeApps.shelf(c, true);
            final List<HomeApps.Item> st = statusList(c);
            final List<HomeApps.Item> d = drawerList(c);
            final List<HomeApps.Item> o = HomeApps.others(c);
            handler.post(() -> {
                setShelf(s);
                setStatusItems(st);
                setDrawerItems(d);
                if (!sheetOpen) setOthers(o);
            });
        });
    }

    // MARK: - Keys: only the arrows, OK and Back (system keys pass through to the system)

    boolean onKey(KeyEvent e) {
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        switch (e.getKeyCode()) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (down) move(-1, 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (down) move(1, 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                if (down) move(0, -1);
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (down) move(0, 1);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                // Opens on release, and only if the press happened here: the release of an OK pressed inside another
                // app opens nothing.
                if (down) {
                    if (e.getRepeatCount() == 0) okDown = true;
                } else {
                    if (okDown && !e.isCanceled() && spoken.keyClick()) activate();
                    okDown = false;
                }
                return true;
            case KeyEvent.KEYCODE_BACK:
                if (down) {
                    if (e.getRepeatCount() == 0) backDown = true;
                } else {
                    if (backDown && !e.isCanceled()) back();
                    backDown = false;
                }
                return true;
            default:
                return false;
        }
    }

    private void back() {
        if (sheetOpen) {
            closeSheet();
        } else if (zone == Z_DRAWER) {
            closeDrawer();
            retarget(false);
        } else if (zone != Z_SHELF) {
            zone = shelfZone();
            retarget(false);
        } else {
            return;
        }
        click.move();
    }

    private void move(int dx, int dy) {
        if (sheetOpen) {
            moveGrid(dx, dy);
            return;
        }
        if (moveLight(dx, dy)) return;
        switch (zone) {
            case Z_SHELF:
                if (dx != 0) {
                    int next = Math.max(0, Math.min(shelf.size() - 1, shelfIndex + dx));
                    if (next == shelfIndex) return;
                    shelfIndex = next;
                } else if (dy < 0) {
                    if (hero != null && hero.button) {
                        zone = Z_HERO;
                    } else if (!statusItems.isEmpty()) {
                        zone = Z_STATUS;
                        statusIndex = shelf.isEmpty() ? 0 : nearest(statusRects, tileRects[shelfIndex].centerX());
                    } else {
                        return;
                    }
                } else {
                    if (drawerItems.isEmpty()) return;
                    openDrawer();
                }
                break;
            case Z_HERO:
                if (dx != 0) {
                    if (!browse(dx)) return;
                } else if (dy < 0) {
                    if (statusItems.isEmpty()) return;
                    zone = Z_STATUS;
                    statusIndex = 0;
                } else {
                    zone = shelfZone();
                }
                break;
            case Z_STATUS:
                if (dx != 0) {
                    int next = Math.max(0, Math.min(statusItems.size() - 1, statusIndex + dx));
                    if (next == statusIndex) return;
                    statusIndex = next;
                } else if (dy > 0) {
                    if (hero != null && hero.button) {
                        zone = Z_HERO;
                    } else {
                        zone = shelfZone();
                        if (!shelf.isEmpty()) shelfIndex = nearest(tileRects, statusRects[statusIndex].centerX());
                    }
                } else {
                    return;
                }
                break;
            default:
                if (dx != 0) {
                    int next = Math.max(0, Math.min(drawerItems.size() - 1, drawerIndex + dx));
                    if (next == drawerIndex) return;
                    drawerIndex = next;
                } else if (dy < 0) {
                    closeDrawer();
                } else {
                    return;
                }
                break;
        }
        retarget(false);
        click.move();
    }

    private static int nearest(RectF[] rects, float x) {
        int best = 0;
        float bestDistance = Float.MAX_VALUE;
        for (int i = 0; i < rects.length; i++) {
            float d = Math.abs(rects[i].centerX() - x);
            if (d < bestDistance) {
                bestDistance = d;
                best = i;
            }
        }
        return best;
    }

    private void moveGrid(int dx, int dy) {
        int n = others.size();
        if (n == 0) return;
        int r = gridIndex / COLUMNS, col = gridIndex % COLUMNS;
        int rows = (n + COLUMNS - 1) / COLUMNS;
        int next = gridIndex;
        if (dx != 0) {
            int candidate = gridIndex + dx;
            if (candidate >= 0 && candidate < n && candidate / COLUMNS == r) next = candidate;
        } else {
            int targetRow = r + dy;
            if (targetRow >= 0 && targetRow < rows) next = Math.min(n - 1, targetRow * COLUMNS + col);
        }
        if (next == gridIndex) return;
        gridIndex = next;
        retargetGrid(false);
        click.move();
        gridDirty = true;
    }

    private void activate() {
        HomeApps.Item it;
        RectF r;
        if(!sheetOpen&&zone==Z_XBOX&&xboxPanel!=null){
            click.open();activity.startActivity(new android.content.Intent(activity,XboxActivity.class));return;
        }
        if (sheetOpen) {
            if (others.isEmpty()) return;
            it = others.get(gridIndex);
            r = focusedCell;
        } else if (zone == Z_HERO) {
            Recs.Pick p = currentPick();
            if (p == null || p.pkg == null) return;
            it = HomeApps.app(p.pkg, Recs.serviceName(p));
            it.url = p.url;
            r = heroButton;
        } else if (zone == Z_STATUS) {
            if (statusItems.isEmpty()) return;
            it = statusItems.get(statusIndex);
            r = statusRects[statusIndex];
        } else if (zone == Z_DRAWER) {
            if (drawerItems.isEmpty()) return;
            it = drawerItems.get(drawerIndex);
            r = drawerRects[drawerIndex];
        } else if (zone == Z_TOP) {
            if (topIndex < 3) {
                selectTab(topIndex);
                return;
            }
            it = lightButtons.get(topIndex - 3);
            r = topRects[topIndex];
        } else if (zone == Z_CARDS) {
            Recs.Pick p = cardIndex < cards.size() ? cards.get(cardIndex) : null;
            if (p == null || p.pkg == null) return;
            it = HomeApps.app(p.pkg, Recs.serviceName(p));
            it.url = p.url;
            cell.set(cardRects[cardIndex]);
            r = cell;
        } else {
            if (shelf.isEmpty()) return;
            it = shelf.get(shelfIndex);
            r = tileRects[shelfIndex];
        }
        click.open();
        if (it.kind == HomeApps.ALL_APPS) {
            openSheet();
            return;
        }
        if (it.kind == HomeApps.INPUTS) {
            openDrawer();
            for (int i = 0; i < drawerItems.size(); i++) {
                if (drawerItems.get(i).kind == HomeApps.INPUT) {
                    drawerIndex = i;
                    break;
                }
            }
            retarget(false);
            return;
        }
        boolean opened = HomeApps.open(activity, it, this, Math.round(r.left), Math.round(r.top),
                Math.round(r.width()), Math.round(r.height()));
        if (!opened) showToast(Ui.tr("Não deu para abrir ", "Couldn't open ") + it.label + ".");
    }

    // MARK: - TalkBack: every reachable item as a virtual node (Spoken). Id = group * 1000 + index + 1.

    private static final int GRID = 9;

    private static int a11yId(int group, int index) {
        return group * 1000 + index + 1;
    }

    @Override public AccessibilityNodeProvider getAccessibilityNodeProvider() {
        return spoken;
    }

    private void a11yItems(List<Integer> out) {
        if (sheetOpen) {
            for (int i = 0; i < others.size(); i++) out.add(a11yId(GRID, i));
            return;
        }
        if(xboxPanel!=null)out.add(a11yId(Z_XBOX,0));
        for (int i = 0; i < 3 + lightButtons.size(); i++) out.add(a11yId(Z_TOP, i));
        for (int i = 0; i < Math.min(CardGrid.LIMIT, cards.size()); i++) out.add(a11yId(Z_CARDS, i));
        for (int i = 0; i < shelf.size(); i++) out.add(a11yId(Z_SHELF, i));
        for (int i = 0; i < drawerItems.size(); i++) out.add(a11yId(Z_DRAWER, i));
    }

    private String a11yText(int id) {
        int group = (id - 1) / 1000, i = (id - 1) % 1000;
        switch (group) {
            case GRID:
                if (i >= others.size()) return "";
                return label(others, i) + ", " + (i + 1) + Ui.tr(" de ", " of ") + others.size();
            case Z_TOP:
                if (i >= 3) return label(lightButtons, i - 3);
                return tabs()[i] + Ui.tr(", aba ", ", tab ") + (i + 1) + Ui.tr(" de 3", " of 3")
                        + (i == tab && cards.isEmpty() ? ". " + emptyTitle + ". " + emptyDetail : "");
            case Z_XBOX: return xboxPanel==null?"":xboxPanel.description();
            case Z_CARDS: return i < cards.size() ? pickText(cards.get(i)) : "";
            case Z_SHELF: return label(shelf, i);
            case Z_DRAWER: return label(drawerItems, i);
            default: return "";
        }
    }

    /**
     * Where the item is now. Items off screen (the closed drawer, the sheet's hidden rows, the top while the drawer is
     * open) get a thin strip at that edge, so TalkBack's arrows can still reach them; going there brings them in.
     */
    private boolean a11yBounds(int id, Rect out) {
        int group = (id - 1) / 1000, i = (id - 1) % 1000;
        float dy;
        switch (group) {
            case GRID: {
                if (!sheetOpen || i >= others.size()) return false;
                float gridWidth = COLUMNS * GRID_W + (COLUMNS - 1) * GRID_GAP;
                float x = ((1920 - gridWidth) / 2 + (i % COLUMNS) * (GRID_W + GRID_GAP)) * k;
                float y = (GRID_TOP + (i / COLUMNS - scroll.target) * GRID_ROW) * k;
                a11yRect.set(x, y, x + GRID_W * k, y + GRID_H * k);
                dy = 0;
                break;
            }
            case Z_TOP:
                if (i >= 3 + lightButtons.size()) return false;
                a11yRect.set(topRects[i]);
                dy = (i < 3 ? heroLayer : status).getTranslationY();
                break;
            case Z_XBOX:
                if(xboxPanel==null||i!=0)return false;
                a11yRect.set(xboxPanel.getLeft(),xboxPanel.getTop(),xboxPanel.getRight(),xboxPanel.getBottom());
                dy=xboxPanel.getTranslationY();break;
            case Z_CARDS:
                if (i >= Math.min(CardGrid.LIMIT, cards.size())) return false;
                a11yRect.set(cardRects[i]);
                dy = heroLayer.getTranslationY();
                break;
            case Z_SHELF:
                if (i >= tileRects.length) return false;
                a11yRect.set(tileRects[i]);
                dy = tiles.getTranslationY();
                break;
            case Z_DRAWER:
                if (i >= drawerRects.length) return false;
                a11yRect.set(drawerRects[i]);
                dy = drawerOpen ? 0 : h;
                break;
            default:
                return false;
        }
        a11yRect.offset(0, dy);
        float edge = 24 * k;
        if (a11yRect.top >= h - edge) a11yRect.set(a11yRect.left, h - edge, a11yRect.right, h);
        else if (a11yRect.bottom <= edge) a11yRect.set(a11yRect.left, 0, a11yRect.right, edge);
        a11yRect.round(out);
        return out.width() > 0 && out.height() > 0;
    }

    private int a11yFocused() {
        if (sheetOpen) return others.isEmpty() ? -1 : a11yId(GRID, gridIndex);
        switch (zone) {
            case Z_XBOX: return xboxPanel==null?-1:a11yId(Z_XBOX,0);
            case Z_TOP: return a11yId(Z_TOP, topIndex);
            case Z_CARDS: return cardIndex < cards.size() ? a11yId(Z_CARDS, cardIndex) : -1;
            case Z_SHELF: return shelf.isEmpty() ? -1 : a11yId(Z_SHELF, shelfIndex);
            case Z_DRAWER: return drawerItems.isEmpty() ? -1 : a11yId(Z_DRAWER, drawerIndex);
            default: return -1;
        }
    }

    /** TalkBack moved to an item: the remote's focus goes there (opening or closing the drawer on the way). */
    private void a11yFocus(int id) {
        int group = (id - 1) / 1000, i = (id - 1) % 1000;
        if (group == GRID) {
            if (!sheetOpen || i >= others.size()) return;
            gridIndex = i;
            retargetGrid(false);
            gridDirty = true;
            click.move();
            return;
        }
        if (sheetOpen) return;
        switch (group) {
            case Z_XBOX:
                if(xboxPanel==null||i!=0)return;
                if(drawerOpen)closeDrawer();xboxReturnTop=topIndex;break;
            case Z_DRAWER:
                if (i >= drawerItems.size()) return;
                if (!drawerOpen) openDrawer();
                drawerIndex = i;
                break;
            case Z_TOP:
                if (i >= 3 + lightButtons.size()) return;
                if (drawerOpen) closeDrawer();
                topIndex = i;
                if (i < 3) selectTab(i);
                break;
            case Z_CARDS:
                if (i >= cards.size()) return;
                if (drawerOpen) closeDrawer();
                cardIndex = i;
                break;
            case Z_SHELF:
                if (i >= shelf.size()) return;
                if (drawerOpen) closeDrawer();
                shelfIndex = i;
                break;
            default:
                return;
        }
        zone = group;
        retarget(false);
        click.move();
    }

    private static String label(List<HomeApps.Item> list, int i) {
        return i >= 0 && i < list.size() && list.get(i).label != null ? list.get(i).label : "";
    }

    /** A recommendation: title, details and the app that plays it. */
    private static String pickText(Recs.Pick p) {
        if (p == null) return "";
        StringBuilder s = new StringBuilder(p.title == null ? "" : p.title);
        if (p.meta != null && !p.meta.isEmpty()) s.append(", ").append(p.meta);
        String app = Recs.serviceName(p);
        if (app != null && !app.isEmpty()) s.append(". App: ").append(app);
        return s.toString();
    }

    // MARK: - Light design: title, tabs, cards and icon-only buttons

    private void layoutLight() {
        if (lTab == null) return;
        // Text tabs; the focus pill extends 26 px past the text (the first tab's text starts at the margin).
        float pad = 26 * k, tabTop = L_TABBAR_TOP * k, tabBottom = (L_TABBAR_TOP + L_TABBAR_H) * k;
        float x = MARGIN * k - pad;
        for (int i = 0; i < 3; i++) {
            float tw = Math.max(lTabOn.measureText(tabs()[i]), lTab.measureText(tabs()[i]));
            topRects[i].set(x, tabTop, x + tw + 2 * pad, tabBottom);
            x = topRects[i].right + 4 * k;
        }
        float b = L_BUTTON * k, right = CONTENT_R * k, cy = L_BUTTON_CY * k;
        for (int i = 2; i >= 0; i--) {
            topRects[3 + i].set(right - b, cy - b / 2, right, cy + b / 2);
            right -= b + L_BUTTON_GAP * k;
        }
        for (int i = 0; i < CardGrid.LIMIT; i++) {
            float left = CardGrid.left(i) * k, top = CardGrid.top(i) * k;
            cardRects[i].set(left, top, left + CardGrid.width() * k, top + CardGrid.HEIGHT * k);
        }
        heroDirty = statusDirty = true;
    }

    /** Stable horizontal pages, with bitmaps only for this group and the next three. */
    private void updateCards() {
        String source = recs.sourceRevision();
        if (recs.resetRecommendations() || !source.equals(railSource)) videoRail.clear();
        railSource = source;
        videoRail.merge(recs.catalog(tabKind()));
        List<Recs.Pick> list = videoRail.current();
        boolean changed = !samePicks(list, cards);
        if (changed) {
            cardIndex = Math.min(cardIndex, Math.max(0, list.size() - 1));
            if (zone == Z_CARDS && list.isEmpty()) {
                zone = shelfZone();
                retarget(false);
            }
        }
        cards = list; // Counts and metadata can change while the video IDs stay the same.
        if (changed) retarget(false);
        updateCardRange();
        recs.prefetch(cards, videoRail.peekNext());
        for (int i = 0; i < CardGrid.LIMIT; i++) {
            Recs.Pick pick = i < cards.size() ? cards.get(i) : null;
            cardBackdrops[i] = pick == null ? null : recs.backdrop(pick);
            cardTitles[i] = null;
            cardMeta[i] = "";
            if (pick != null && lCardTitle != null && cardRects[i].width() > 0) {
                String title = pick.title == null ? "" : pick.title;
                TextPaint tp = new TextPaint(lCardTitle);
                cardTitles[i] = StaticLayout.Builder.obtain(title, 0, title.length(), tp,
                        Math.max(1, Math.round(cardRects[i].width() - 32 * k)))
                        .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).setIncludePad(false).build();
                String meta = pick.meta == null ? "YouTube" : pick.meta;
                cardMeta[i] = TextUtils.ellipsize(meta, new TextPaint(lCardMeta),
                        cardRects[i].width() - 32 * k, TextUtils.TruncateAt.END).toString();

            }
        }
        if (skin.glass) showBackdrop(cards.isEmpty() ? null : cardBackdrops[0]);
        // Non-glass skins own their fixed background instead of using feed thumbnails.
        heroDirty = true;
        spoken.focusMoved();    // new picks under the focused card
    }

    private void selectTab(int index) {
        if (index == tab) return;
        tab = index;
        videoRail.clear();
        cardIndex = 0;
        updateCards();
        heroDirty = true;
    }

    /** Fixed graphite or a softly blurred day/night photo backdrop. */
    private void drawLightSky(Canvas c) {
        if (skin == Skin.GTA_VI) {
            c.drawColor(theme.BACKGROUND);
            if(gameWallpaperFrom!=null)drawImage(c,gameWallpaperFrom,1);
            if(gameWallpaper!=null)drawImage(c,gameWallpaper,gameWallpaperFadeAt==0?1:fadeEase(gameWallpaperFadeAt,SystemClock.uptimeMillis()));
            return;
        }
        if (!skin.glass) {
            c.drawColor(theme.BACKGROUND);

            return;
        }
        long up = SystemClock.uptimeMillis();
        float e = bgFadeAt == 0 ? 1 : fadeEase(bgFadeAt, up);
        boolean fading = bgFadeAt != 0;
        // Drawer open: the background lightens (by day) or darkens (at night), as a filter on the drawing itself.
        android.graphics.ColorFilter v = veil(tone(0.32f, 0.42f) * Ui.clamp(drawer.value), blend(0xFFFFFFFF, 0xFF000000, night));
        if (bgTo == null || (fading && bgFrom == null)) {
            if (lightGradient == null) lightGradient = new LinearGradient(0, 0, 0, h, 0xFFF5F5F7, 0xFFE2E2E7, Shader.TileMode.CLAMP);
            if (nightGradient == null) nightGradient = new LinearGradient(0, 0, 0, h, 0xFF1C1C1E, 0xFF0B0B0D, Shader.TileMode.CLAMP);
            fill.setColorFilter(v);
            if (night < 0.999f) {
                fill.setShader(lightGradient);
                c.drawRect(screen, fill);
            }
            if (night > 0.001f) {
                fill.setShader(nightGradient);
                fill.setAlpha(Math.round(255 * night));
                c.drawRect(screen, fill);
                fill.setAlpha(255);
            }
            fill.setShader(null);
            fill.setColorFilter(null);
        }
        imagePaint.setColorFilter(v);
        if (fading && bgFrom != null) drawLightImage(c, bgFrom, bgTo == null ? 1 - e : 1);
        if (bgTo != null) drawLightImage(c, bgTo, fading ? e : 1);
        imagePaint.setColorFilter(null);
    }

    private void drawLightImage(Canvas c, Backdrop b, float alpha) {
        if (night < 0.999f || b.nightImage == null) drawImage(c, b.lightImage, alpha);
        if (night > 0.001f) drawImage(c, b.nightImage, alpha * night);
    }

    private void drawLightTop(Canvas c) {
        applyTone();
        if (skin.glass) {
            String hello = "ViktorKav";
            c.drawText(hello, MARGIN * k - Ui.leftBearing(lTitle, hello), L_TITLE_BASE * k, lTitle);
            cell.set(topRects[0].left, topRects[0].top, topRects[2].right, topRects[2].bottom);
            scene.liquid(c, cell, cell.height() / 2, tone(0xFFFFFFFF, SMOKE), tone(.18f, .10f),
                    .02f, 16 * k, 12 * k, .8f, 1);
            for (int i = 0; i < 3; i++) {
                RectF r = topRects[i];
                float f = Ui.clamp(topFocus[i].value);
                if (i == tab) {
                    cell.set(r);
                    cell.inset(4 * k, 4 * k);
                    fill.setShader(null);
                    fill.setColor(Ui.alpha(0xFFFFFFFF, tone(.22f, .12f) + (.72f - tone(.22f, .12f)) * f));
                    c.drawRoundRect(cell, cell.height() / 2, cell.height() / 2, fill);
                }
                Paint p = i == tab ? lTabOn : lTab;
                p.setColor(i == tab ? blend(theme.TEXT, theme.ON_FOCUS, f) : theme.SECONDARY);
                c.drawText(tabs()[i], r.centerX() - p.measureText(tabs()[i]) / 2, r.centerY() + Ui.halfCap(p), p);
            }
        } else {
            if (skin == Skin.GTA_VI) {
                c.drawText("GTA VI", MARGIN * k, 120 * k, lTitle);
                c.drawText("FREE MY TV · VIKTORKAV", MARGIN * k, 147 * k, brandLabel);
            } else {
                Ui.brand(c, MARGIN * k, 70 * k, 56 * k);
                c.drawText("ViktorKav", 158 * k, 120 * k, lTitle);
                c.drawText(Ui.tr("TV / SUAS INSCRIÇÕES", "TV / YOUR SUBSCRIPTIONS"), 160 * k, 147 * k, brandLabel);
            }
            border.setColor(theme.LINE);
            c.drawLine(MARGIN * k, 244 * k, CONTENT_R * k, 244 * k, border);
            for (int i = 0; i < 3; i++) {
                RectF r = topRects[i];
                float f = Ui.clamp(topFocus[i].value);
                if (f > 0.01f) {
                    fill.setShader(null);
                    fill.setColor(Ui.alpha(theme.FOCUS_FIELD, f));
                    c.drawRoundRect(r, skin.radius * k, skin.radius * k, fill);
                    rim.setColor(Ui.alpha(theme.FOCUS, f));
                    c.drawRoundRect(r, skin.radius * k, skin.radius * k, rim);
                }
                Paint p = i == tab ? lTabOn : lTab;
                c.drawText(tabs()[i], r.centerX() - p.measureText(tabs()[i]) / 2, r.centerY() + Ui.halfCap(p), p);
                if (i == tab) {
                    fill.setShader(null);
                    fill.setColor(theme.FOCUS);
                    c.drawRect(r.left + 26 * k, r.bottom - 3 * k, r.right - 26 * k, r.bottom, fill);
                }
        }
        }
        if (cards.isEmpty()) {
            float cx = w / 2f;
            c.drawText(emptyTitle, cx - lCardTitle.measureText(emptyTitle) / 2, 444 * k, lCardTitle);
            c.drawText(emptyDetail, cx - lCardMeta.measureText(emptyDetail) / 2, 492 * k, lCardMeta);
        }
        c.save();
        c.clipRect(40 * k, 246 * k, w - 40 * k, 792 * k);
        int top = -1;
        for (int i = 0; i < cards.size(); i++) if (cardFocus[i].value > 0.02f && (top < 0 || cardFocus[i].value > cardFocus[top].value)) top = i;
        for (int i = 0; i < cards.size(); i++) if (i != top) drawLightCard(c, i);
        if (top >= 0) drawLightCard(c, top);
        c.restore();
        if (!cards.isEmpty()) c.drawText(cardRange, MARGIN * k, 800 * k, brandLabel);
        if (Config.SHOW_CHANNEL_METRICS) drawMetrics(c);
    }

    /** Full-width 16:9 thumbnails with title and channel below. */
    private void drawLightCard(Canvas c, int i) {
        if (i >= cards.size()) return;
        RectF base = cardRects[i];
        float v = cardFocus[i].value, f = Ui.clamp(v), scale = 1 + 0.05f * v;
        float bw = base.width(), bh = base.height(), radius = skin.radius * k;
        float cx = base.centerX(), cy = base.centerY() - 6 * k * v;
        c.save();
        c.translate(cx, cy);
        c.scale(scale, scale);
        cell.set(-bw / 2, -bh / 2, bw / 2, bh / 2);
        tmp.set(cell);
        tmp.offset(0, (10 + 14 * f) * k);
        shadowDeep.setColor(Ui.alpha(0xFF000000, tone(0.14f, 0.32f) + tone(0.2f, 0.28f) * f));
        c.drawRoundRect(tmp, radius, radius, shadowDeep);
        fill.setShader(null);
        if (skin.glass) {
            scene.setOffset(cx, cy + heroLayer.getTranslationY());
            scene.liquid(c, cell, radius, tone(0xFFFFFFFF, SMOKE), tone(.28f, .18f), .02f,
                    18 * k, 12 * k, .65f, 1);
            scene.setOffset(0, 0);
        } else {
            fill.setColor(blend(theme.SURFACE, theme.RAISED, f));
            c.drawRoundRect(cell, radius, radius, fill);
        }
        clip.reset();
        clip.addRoundRect(cell, radius, radius, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        tmp.set(cell.left, cell.top, cell.right, cell.top + bw * 9 / 16);
        Backdrop backdrop = cardBackdrops[i];
        Bitmap image = backdrop == null ? null : backdrop.wide;
        if (image != null) {
            c.drawBitmap(image, null, tmp, bitmapPaint);
        } else {
            fill.setColor(theme.FIELD);
            c.drawRect(tmp, fill);
            String loading = Ui.tr("Miniatura indisponível", "Thumbnail unavailable");
            c.drawText(loading, -lCardMeta.measureText(loading) / 2, tmp.centerY() + Ui.halfCap(lCardMeta), lCardMeta);
        }
        c.restore();
        StaticLayout title = cardTitles[i];
        if (title != null) {
            title.getPaint().setColor(lCardTitle.getColor());
            c.save();
            c.translate(cell.left + 16 * k, cell.top + bw * 9 / 16 + 12 * k);
            title.draw(c);
            c.restore();
        }
        c.drawText(cardMeta[i], cell.left + 16 * k, cell.bottom - 16 * k, lCardMeta);
        if (f > 0.01f) {
            rim.setShader(null);
            rim.setColor(Ui.alpha(theme.FOCUS, f));
            c.drawRoundRect(cell, radius, radius, rim);
        }
        c.restore();
    }

    /** Corner actions share the graphite surface and explicit remote focus. */
    private void drawLightButtons(Canvas c) {
        if (!skin.glass) {
            applyTone();
            for (int i = 0; i < 3; i++) {
                RectF r = topRects[3 + i];
                float f = Ui.clamp(topFocus[3 + i].value), radius = skin.radius * k;
                fill.setShader(null);
                fill.setColor(blend(theme.FIELD, theme.FOCUS_FIELD, f));
                c.drawRoundRect(r, radius, radius, fill);
                if (f > 0.01f) {
                    rim.setColor(Ui.alpha(theme.FOCUS, f));
                    c.drawRoundRect(r, radius, radius, rim);
                }
                Symbols.draw(getContext(), c, lightButtons.get(i).symbol, r.centerX(), r.centerY(), 27 * k,
                        blend(theme.SECONDARY, theme.FOCUS, f));
                if (f > 0.01f) {
                    String label = lightButtons.get(i).label;
                    float half = lTip.measureText(label) / 2;
                    float x = Math.min(r.centerX(), CONTENT_R * k - half);
                    lTip.setAlpha(Math.round(255 * f));
                    c.drawText(label, x, r.bottom + 40 * k, lTip);
                }
            }

            return;
        }
        applyTone();
        for (int i = 0; i < 3; i++) {
            RectF r = topRects[3 + i];
            float f = Ui.clamp(topFocus[3 + i].value), s = 1 + 0.1f * f, rad = r.width() / 2 * s;
            cell.set(r.centerX() - rad, r.centerY() - rad, r.centerX() + rad, r.centerY() + rad);
            tmp.set(cell);
            tmp.offset(0, (6 + 8 * f) * k);
            shadow.setColor(Ui.alpha(0xFF000000, tone(0.1f, 0.3f) + tone(0.14f, 0.2f) * f));
            c.drawRoundRect(tmp, rad, rad, shadow);
            scene.liquid(c, cell, rad, tone(0xFFFFFFFF, SMOKE), tone(0.20f, 0.12f), tone(0.02f, 0.01f), 12 * k, 8 * k,
                    tone(0.6f, 0.45f), 1 - f);
            if (f > 0.01f) {
                fill.setShader(null);
                fill.setColor(Ui.alpha(0xFFFFFFFF, f));
                c.drawCircle(cell.centerX(), cell.centerY(), rad, fill);
            }
            Symbols.draw(getContext(), c, lightButtons.get(i).symbol, cell.centerX(), cell.centerY(), 27 * k * s,
                    blend(tone(L_INK, 0xEBFFFFFF), L_INK, f));
            if (f > 0.01f) {
                String label = lightButtons.get(i).label;
                float half = lTip.measureText(label) / 2;
                float x = Math.min(r.centerX(), CONTENT_R * k - half);
                lTip.setAlpha(Math.round(255 * f));
                c.drawText(label, x, r.bottom + (40 + 4 * f) * k, lTip);
            }
        }
    }

    private void updateCardRange() {
        if (cards.isEmpty()) { cardRange = ""; return; }
        int start = videoRail.start();
        cardRange = (start > 0 ? "←  " : "") + (start + 1) + "–" + (start + cards.size())
                + (videoRail.peekNext().isEmpty() ? Ui.tr("  /  FIM DAS SUGESTÕES DISPONÍVEIS", "  /  END OF AVAILABLE SUGGESTIONS")
                : Ui.tr("  /  MAIS VÍDEOS  →", "  /  MORE VIDEOS  →"));
    }

    private int nearestCard(float x) {
        return nearest(cardRects, cards.size(), x);
    }

    private boolean moveLight(int dx, int dy) {
        switch (zone) {
            case Z_XBOX:
                if(dy>0||dx!=0){zone=Z_TOP;topIndex=Math.max(0,Math.min(5,xboxReturnTop));}
                else return true;
                break;
            case Z_SHELF:
                if (dy >= 0 || shelf.isEmpty()) return false;
                if (cards.isEmpty()) { zone = Z_TOP; topIndex = tab; }
                else { zone = Z_CARDS; cardIndex = nearestCard(tileRects[shelfIndex].centerX()); }
                break;
            case Z_CARDS: {
                int next = CardGrid.next(cardIndex, dx, dy, cards.size());
                if (next >= 0) {
                    if (next == cardIndex) return true;
                    cardIndex = next;
                } else if (dx != 0) {
                    boolean moved = dx > 0 ? videoRail.next() : videoRail.previous();
                    if (!moved) {
                        if (dx > 0) {
                            recs.refreshIfStale();
                            showToast(Ui.tr("Você viu as sugestões disponíveis. Novos vídeos entram ao atualizar.",
                                    "You've seen the available suggestions. New videos appear on refresh."));
                        }
                        return true;
                    }
                    cardIndex = 0;
                    updateCards();
                    if (dx < 0) cardIndex = Math.max(0, cards.size() - 1);
                } else if (dy < 0) { zone = Z_TOP; topIndex = tab; }
                else {
                    if(shelf.isEmpty())openDrawer(); else zone = shelfZone();
                    if (!shelf.isEmpty()) shelfIndex = nearest(tileRects, tileRects.length, cardRects[cardIndex].centerX());
                }
                break;
            }
            case Z_TOP:
                if (dx != 0) {
                    int next = Math.max(0, Math.min(5, topIndex + dx));
                    if (next == topIndex) return true;
                    topIndex = next;
                    if (topIndex < 3) selectTab(topIndex);
                } else if (dy > 0) {
                    if (cards.isEmpty()) { if(shelf.isEmpty())openDrawer(); else zone = shelfZone(); }
                    else {
                        zone = Z_CARDS;
                        cardIndex = nearestCard(topRects[topIndex].centerX());
                    }
                } else if(dy<0&&xboxPanel!=null){xboxReturnTop=topIndex;zone=Z_XBOX;}
                else return true;
                break;
            default:
                return false;
        }
        retarget(false);
        click.move();
        return true;
    }

    private static int nearest(RectF[] rects, int count, float x) {
        int best = 0;
        float bestDistance = Float.MAX_VALUE;
        for (int i = 0; i < Math.min(count, rects.length); i++) {
            float d = Math.abs(rects[i].centerX() - x);
            if (d < bestDistance) {
                bestDistance = d;
                best = i;
            }
        }
        return best;
    }

    // MARK: - Helpers

    private static float smoothstep(float e0, float e1, float x) {
        float t = Ui.clamp((x - e0) / (e1 - e0));
        return t * t * (3 - 2 * t);
    }

    private static int blend(int a, int b, float f) {
        int aa = a >>> 24, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = b >>> 24, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return (Math.round(aa + (ba - aa) * f) << 24) | (Math.round(ar + (br - ar) * f) << 16)
                | (Math.round(ag + (bg - ag) * f) << 8) | Math.round(ab + (bb - ab) * f);
    }
}
